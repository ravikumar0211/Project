package com.mashreq.neofxrates.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.mashreq.neofxrates.dto.DealBookingRequest;
import com.mashreq.neofxrates.dto.DealBookingResponse;
import com.mashreq.neofxrates.service.DealBookingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dealbooking")
public class DealBookingController {

    private final DealBookingService service;

    public DealBookingController(DealBookingService service) {
        this.service = service;
    }

    /*
     * Main OBPAY Deal Booking flow:
     *
     * 1. Call Accept Quote -> downstream POST /v2/rfs/{requestId}
     * 2. If Accept Quote succeeds, call Query Quote -> downstream GET /v2/rfs/{requestId}
     * 3. Return both responses to OBPAY.
     *
     * No SSO_TOKEN, no retry and no cached-rate fallback.
     */
    @PostMapping
    public ResponseEntity<DealBookingResponse> dealBooking(
            @Valid @RequestBody DealBookingRequest request) {

        return ResponseEntity.ok(service.execute(request));
    }

    /*
     * Individual testing endpoint for Accept Quote.
     */
    @PostMapping("/acceptquote")
    public ResponseEntity<JsonNode> acceptQuote(
            @Valid @RequestBody DealBookingRequest request) {

        return ResponseEntity.ok(service.acceptQuote(request));
    }

    /*
     * Individual testing endpoint for Query Quote.
     * This is intentionally a GET because the downstream Query Quote API is GET.
     */
    @GetMapping("/queryquote/{requestId}")
    public ResponseEntity<JsonNode> queryQuote(
            @PathVariable String requestId) {

        return ResponseEntity.ok(service.queryQuote(requestId));
    }
}
