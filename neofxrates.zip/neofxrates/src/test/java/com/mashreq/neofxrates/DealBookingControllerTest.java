package com.mashreq.neofxrates;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.controller.DealBookingController;
import com.mashreq.neofxrates.dto.DealBookingFlowRequest;
import com.mashreq.neofxrates.dto.DealBookingFlowResponse;
import com.mashreq.neofxrates.service.DealBookingService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class DealBookingControllerTest {
    @Test
    void controllerExposesSingleBusinessMethod() {
        DealBookingService service = Mockito.mock(DealBookingService.class);
        DealBookingController controller = new DealBookingController(service);
        DealBookingFlowResponse response = new DealBookingFlowResponse(); response.setFlowStatus("COMPLETED");
        Mockito.when(service.getcalled(any(DealBookingFlowRequest.class))).thenReturn(ResponseEntity.ok(response));
        ResponseEntity<DealBookingFlowResponse> result = controller.dealBooking(new DealBookingFlowRequest());
        assertEquals(200, result.getStatusCode().value());
        assertEquals("COMPLETED", result.getBody().getFlowStatus());
    }
}
