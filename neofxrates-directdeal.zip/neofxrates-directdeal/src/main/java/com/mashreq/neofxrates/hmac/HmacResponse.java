package com.mashreq.neofxrates.hmac;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HmacResponse {

    private String username;
    private String date;
    private String digest;
    private String type;
    private String requestLine;
    private String signingString;
    private String signature;
    private String authorization;
}
