package com.mashreq.neofxrates.hmac;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

public class IntegralHmacInterceptor
        implements ClientHttpRequestInterceptor {

    private final IntegralHmacProperties properties;

    public IntegralHmacInterceptor(
            IntegralHmacProperties properties
    ) {
        this.properties = properties;
    }

    @Override
    public ClientHttpResponse intercept(
            HttpRequest request,
            byte[] body,
            ClientHttpRequestExecution execution
    ) throws IOException {

        /*
         * ------------------------------------------------------------
         * LOGIN DOES NOT USE HMAC
         * ------------------------------------------------------------
         *
         * POST /v2/sso/login is sent without HMAC authentication.
         */
        if (!properties.isEnabled()
                || isLoginRequest(request.getURI())) {

            return execution.execute(request, body);
        }

        /*
         * ------------------------------------------------------------
         * VALIDATE HMAC CONFIGURATION
         * ------------------------------------------------------------
         */
        if (!StringUtils.hasText(properties.getUsername())) {

            throw new IllegalStateException(
                    "HMAC username is not configured. " +
                            "Set app.hmac.username or " +
                            "INTEGRAL_HMAC_USERNAME."
            );
        }

        if (!StringUtils.hasText(properties.getSecret())) {

            throw new IllegalStateException(
                    "HMAC secret is not configured. " +
                            "Set app.hmac.secret or " +
                            "INTEGRAL_HMAC_SECRET."
            );
        }

        HttpHeaders headers = request.getHeaders();

        /*
         * ------------------------------------------------------------
         * 1. DATE
         * ------------------------------------------------------------
         *
         * Postman generates an RFC-1123 UTC date.
         */
        String date =
                DateTimeFormatter.RFC_1123_DATE_TIME.format(
                        ZonedDateTime.now(ZoneOffset.UTC)
                );

        /*
         * ------------------------------------------------------------
         * 2. BODY DIGEST
         * ------------------------------------------------------------
         *
         * SHA-256(body)
         *
         * Then Base64 encode.
         *
         * IMPORTANT:
         * There is NO:
         *
         * SHA-256=
         *
         * prefix.
         */
        String digest = sha256Base64(body);

        headers.set("Date", date);
        headers.set("Digest", digest);

        /*
         * Postman explicitly sets:
         *
         * type: hmac
         */
        headers.set("type", "hmac");

        /*
         * ------------------------------------------------------------
         * 3. BUILD REQUEST PATH FOR SIGNING
         * ------------------------------------------------------------
         *
         * Actual URL:
         *
         * https://uat.fxinside.net/v2/rfs
         *
         * Signed request line:
         *
         * POST /rfs HTTP/1.1
         *
         * because /v2 is stripped before signing.
         */
        String pathForSigning =
                pathWithQuery(request.getURI());

        String stripPrefix =
                properties.getStripPathPrefix();

        if (StringUtils.hasText(stripPrefix)
                && pathForSigning.regionMatches(
                true,
                0,
                stripPrefix,
                0,
                stripPrefix.length()
        )) {

            pathForSigning =
                    pathForSigning.substring(
                            stripPrefix.length()
                    );
        }

        if (!pathForSigning.startsWith("/")) {
            pathForSigning =
                    "/" + pathForSigning;
        }

        /*
         * ------------------------------------------------------------
         * 4. REQUEST LINE
         * ------------------------------------------------------------
         */
        String requestLine =
                request.getMethod().name()
                        + " "
                        + pathForSigning
                        + " HTTP/1.1";

        /*
         * ------------------------------------------------------------
         * 5. HEADERS TO SIGN
         * ------------------------------------------------------------
         *
         * Default:
         *
         * date request-line digest
         *
         * We read the configured value so it can match Postman.
         */
        String configuredHeaders =
                properties.getHeaders();

        if (!StringUtils.hasText(configuredHeaders)) {

            configuredHeaders =
                    "date request-line digest";
        }

        String[] headersToSign =
                configuredHeaders
                        .toLowerCase(Locale.ROOT)
                        .trim()
                        .split("\\s+");

        /*
         * ------------------------------------------------------------
         * 6. BUILD SIGNING STRING
         * ------------------------------------------------------------
         *
         * Example:
         *
         * date: Thu, 17 Sep 2026 15:21:50 GMT
         * POST /rfs HTTP/1.1
         * digest: abcdef...
         *
         * Lines are separated by LF.
         *
         * There is NO trailing newline.
         */
        StringBuilder signingBuilder =
                new StringBuilder();

        for (int i = 0;
             i < headersToSign.length;
             i++) {

            if (i > 0) {
                signingBuilder.append('\n');
            }

            String headerName =
                    headersToSign[i];

            if ("request-line".equals(headerName)) {

                signingBuilder.append(
                        requestLine
                );

            } else if ("date".equals(headerName)) {

                signingBuilder.append(
                        "date: "
                ).append(date);

            } else if ("digest".equals(headerName)) {

                signingBuilder.append(
                        "digest: "
                ).append(digest);

            } else {

                String headerValue =
                        headers.getFirst(headerName);

                if (headerValue == null) {
                    headerValue = "";
                }

                signingBuilder
                        .append(headerName)
                        .append(": ")
                        .append(headerValue);
            }
        }

        String signingString =
                signingBuilder.toString();

        /*
         * ------------------------------------------------------------
         * 7. GENERATE HMAC-SHA256
         * ------------------------------------------------------------
         */
        String signature =
                hmacSha256Base64(
                        signingString,
                        properties.getSecret(),
                        properties.getSecretEncoding()
                );

        /*
         * ------------------------------------------------------------
         * 8. BUILD AUTHORIZATION HEADER
         * ------------------------------------------------------------
         *
         * IMPORTANT:
         *
         * Postman uses:
         *
         * username
         *
         * NOT:
         *
         * userId
         */
        String authorization =
                "hmac username=\""
                        + properties.getUsername()
                        + "\", algorithm=\"hmac-sha256\""
                        + ", headers=\""
                        + String.join(
                        " ",
                        headersToSign
                )
                        + "\", signature=\""
                        + signature
                        + "\"";

        headers.set(
                HttpHeaders.AUTHORIZATION,
                authorization
        );

        /*
         * ------------------------------------------------------------
         * DEBUG LOGGING
         * ------------------------------------------------------------
         *
         * NEVER print the HMAC secret.
         */
        System.out.println(
                "========== INTEGRAL HMAC =========="
        );

        System.out.println(
                "HTTP URL       : "
                        + request.getURI()
        );

        System.out.println(
                "HTTP Method    : "
                        + request.getMethod()
        );

        System.out.println(
                "Request Line   : "
                        + requestLine
        );

        System.out.println(
                "Date           : "
                        + date
        );

        System.out.println(
                "Digest         : "
                        + digest
        );

        System.out.println(
                "Headers Signed : "
                        + String.join(
                        " ",
                        headersToSign
                )
        );

        System.out.println(
                "Signing String :"
        );

        System.out.println(
                signingString
        );

        System.out.println(
                "Username       : "
                        + properties.getUsername()
        );

        System.out.println(
                "Secret exists  : "
                        + StringUtils.hasText(
                        properties.getSecret()
                )
        );

        System.out.println(
                "Secret length  : "
                        + properties.getSecret().length()
        );

        System.out.println(
                "Authorization  : "
                        + authorization
        );

        System.out.println(
                "==================================="
        );

        return execution.execute(
                request,
                body
        );
    }

    /**
     * Login endpoint must not be HMAC signed.
     */
    private boolean isLoginRequest(URI uri) {

        String path = uri.getPath();

        return path != null
                && path.endsWith(
                "/v2/sso/login"
        );
    }

    /**
     * Returns raw URI path including query parameters.
     */
    private String pathWithQuery(URI uri) {

        String path =
                uri.getRawPath();

        if (path == null
                || path.isEmpty()) {

            path = "/";
        }

        String query =
                uri.getRawQuery();

        if (query == null
                || query.isEmpty()) {

            return path;
        }

        return path + "?" + query;
    }

    /**
     * SHA-256 body digest.
     *
     * Result:
     *
     * Base64(SHA-256(body))
     */
    private String sha256Base64(
            byte[] body
    ) {

        try {

            byte[] hash =
                    MessageDigest
                            .getInstance("SHA-256")
                            .digest(body);

            return Base64
                    .getEncoder()
                    .encodeToString(hash);

        } catch (Exception e) {

            throw new IllegalStateException(
                    "Unable to calculate SHA-256 digest",
                    e
            );
        }
    }

    /**
     * HMAC-SHA256 + Base64.
     *
     * utf8:
     *     secret is used directly as UTF-8 bytes.
     *
     * base64:
     *     secret is first Base64 decoded.
     */
    private String hmacSha256Base64(
            String value,
            String secret,
            String encoding
    ) {

        try {

            byte[] key;

            if ("base64".equalsIgnoreCase(
                    encoding
            )) {

                key =
                        Base64
                                .getDecoder()
                                .decode(secret);

            } else {

                key =
                        secret.getBytes(
                                StandardCharsets.UTF_8
                        );
            }

            Mac mac =
                    Mac.getInstance(
                            "HmacSHA256"
                    );

            SecretKeySpec secretKey =
                    new SecretKeySpec(
                            key,
                            "HmacSHA256"
                    );

            mac.init(secretKey);

            byte[] result =
                    mac.doFinal(
                            value.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            return Base64
                    .getEncoder()
                    .encodeToString(result);

        } catch (Exception e) {

            throw new IllegalStateException(
                    "Unable to calculate Integral HMAC signature",
                    e
            );
        }
    }
}