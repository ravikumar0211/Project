# NEOFX Direct Deal API

This project implements the Direct Deal orchestration requested from the supplied Postman workflow and follows the HMAC implementation pattern from the supplied `obms-neofxrates-api` reference project.

## External workflow

The application calls the downstream APIs in this exact order:

```text
OBPAY / DirectDeal
       |
       v
1. POST /v2/sso/login
   HMAC authenticated
   |
   | successful HTTP response
   v
2. POST /v2/orders
   HMAC authenticated
   |
   | orderId from response
   v
3. GET /v2/orders/{orderId}
   HMAC authenticated
   |
   | order must be FILLED
   | averagePrice becomes coverRate/fillRate
   v
4. POST /v2/trades
   HMAC authenticated
   |
   v
Book Trade response
```

Every downstream request is independently signed by `IntegralHmacInterceptor`. The login response is **not** converted to or stored as an SSO token, and no SSO-token header is sent to the downstream APIs.

## HMAC implementation

The HMAC implementation follows the supplied reference project:

- `Date`: RFC-1123 UTC
- `Digest`: raw Base64 SHA-256 of the exact request body
- `type: hmac`
- signed headers: `date request-line digest`
- `/v2` is stripped from the signed request-line
- request line format: `METHOD /path HTTP/1.1`
- HMAC-SHA256
- secret uses UTF-8 by default
- Authorization uses `username="..."`

Example authorization shape:

```text
hmac username="NEOFXAPI@NEOFX", algorithm="hmac-sha256",
headers="date request-line digest", signature="..."
```

## Internal endpoint

Start the application and call:

```text
POST http://localhost:8080/api/v1/directdeal
Content-Type: application/json
```

Request:

```json
{
  "login": {
    "user": "prov",
    "pass": "YOUR_LOGIN_PASSWORD",
    "org": "NEOFX"
  },
  "directDeal": {
    "symbol": "EUR/USD",
    "side": "BUY",
    "amount": 1000,
    "dealtCurrency": "EUR",
    "rate": 1.1700,
    "spotRate": 1.1700,
    "rateId": "DIRECT-RATE-001",
    "referenceId": "OBPAY-001",
    "customerOrg": "NEOFX_UAE_CIBG_Regular",
    "customerAccount": "NEOFX_UAE_CIBG_Regular"
  }
}
```

The final HTTP response is the downstream Book Trade response.

## Environment

Set the HMAC secret outside source control:

```bash
export FX_BASE_URL=https://uat.fxinside.net
export INTEGRAL_HMAC_USERNAME='NEOFXAPI@NEOFX'
export INTEGRAL_HMAC_SECRET='YOUR_HMAC_SECRET'
export INTEGRAL_HMAC_SECRET_ENCODING='utf8'
export INTEGRAL_HMAC_STRIP_PATH_PREFIX='/v2'
export INTEGRAL_HMAC_HEADERS='date request-line digest'
```

The login password is part of the `/v2/sso/login` JSON body and is not the HMAC secret.

## Postman

The `postman/NEOFXRATES1-Direct-Deal-HMAC.postman_collection.json` collection contains:

1. Login (HMAC)
2. Place Order (At Best)
3. Query Order
4. Book Trade
5. Complete Internal Direct Deal

The internal request executes the four downstream calls automatically.

## Swagger

Swagger/OpenAPI UI is intentionally removed. There is no `springdoc` dependency and no Swagger controller annotation.

## Build

```bash
./mvnw clean test
./mvnw spring-boot:run
```

On Windows:

```bat
mvnw.cmd clean test
mvnw.cmd spring-boot:run
```
