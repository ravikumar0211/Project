package com.mashreq.obms.neofxrates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeofxratesApplication {
    public static void main(String[] args) {
        SpringApplication.run(NeofxratesApplication.class, args);
    }
}
