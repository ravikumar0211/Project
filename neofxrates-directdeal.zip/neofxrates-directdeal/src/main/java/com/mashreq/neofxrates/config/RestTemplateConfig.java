package com.mashreq.neofxrates.config;

import com.mashreq.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.neofxrates.hmac.IntegralHmacService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {
    @Bean
    public IntegralHmacService integralHmacService(IntegralHmacProperties properties) {
        return new IntegralHmacService(properties);
    }
    @Bean
    public RestTemplate restTemplate(ApplicationConfig config, IntegralHmacProperties properties, IntegralHmacService service) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(config.getConnectTimeoutMs());
        factory.setReadTimeout(config.getReadTimeoutMs());
        RestTemplate restTemplate = new RestTemplate(factory);
        // Colleague-project pattern: HMAC interceptor signs every outbound FX request, including login.
        restTemplate.getInterceptors().add(new IntegralHmacInterceptor(properties, service));
        return restTemplate;
    }
}
