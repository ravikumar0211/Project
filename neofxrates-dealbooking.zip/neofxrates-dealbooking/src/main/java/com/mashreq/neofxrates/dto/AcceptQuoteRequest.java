package com.mashreq.neofxrates.dto;

public record AcceptQuoteRequest(
        String requestId,
        String quoteId,
        String side,
        String symbol,
        String dealtCurrency,
        String transactionId,
        String clOrderId,
        String rfq,
        String cif,
        String refNo,
        String source
) {
}