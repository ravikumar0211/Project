package com.mashreq.obms.neofxrates.service;

import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.ObpayDealBookingResponse;
import com.mashreq.obms.neofxrates.msApi.FxIntegralAcceptQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DealBookingService {
    private final FxIntegralAcceptQuoteApi acceptQuoteApi;
    private final FxIntegralQueryQuoteApi queryQuoteApi;
    private final DealBookingResponseMapper responseMapper;

    public ObpayDealBookingResponse acceptQuoteAndQuery(DealBookingRequest request) {
        validate(request);
        AcceptQuoteRequest acceptRequest = request.toAcceptQuoteRequest();

        ResponseEntity<String> acceptResponse = acceptQuoteApi.acceptQuote(request.getRequestId(), acceptRequest);
        if (acceptResponse == null || !acceptResponse.getStatusCode().is2xxSuccessful()) {
            throw new IllegalStateException("Integral Accept Quote failed");
        }

        ResponseEntity<String> queryResponse = queryQuoteApi.queryQuote(request.getRequestId());
        if (queryResponse == null || !queryResponse.getStatusCode().is2xxSuccessful() || queryResponse.getBody() == null) {
            throw new IllegalStateException("Integral Query Quote failed");
        }

        return responseMapper.map(request.getRequestId(), acceptRequest, queryResponse.getBody());
    }

    private void validate(DealBookingRequest request) {
        if (request == null || isBlank(request.getRequestId()) || isBlank(request.getQuoteId())) {
            throw new IllegalArgumentException("requestId and quoteId are required");
        }
    }

    private boolean isBlank(String value) { return value == null || value.isBlank(); }
}
