package com.mashreq.obms.neofxrates.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DealBookingRequest {
    private String requestId;
    private String quoteId;
    private String side;
    private String symbol;
    private String dealtCurrency;
    private String transactionId;
    private String clOrderId;
    private Boolean rfq;

    public AcceptQuoteRequest toAcceptQuoteRequest() {
        AcceptQuoteRequest request = new AcceptQuoteRequest();
        request.setQuoteId(quoteId);
        request.setSide(side);
        request.setSymbol(symbol);
        request.setDealtCurrency(dealtCurrency);
        request.setTransactionId(transactionId);
        request.setClOrderId(clOrderId);
        request.setRfq(rfq);
        return request;
    }
}
