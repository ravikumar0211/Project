package com.mashreq.neofxrates.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class DealBookingFlowRequest {
    @NotNull @Valid private LoginRequest login;
    @NotNull @Valid private AcceptQuoteRequest acceptQuote;
    public LoginRequest getLogin() { return login; }
    public void setLogin(LoginRequest login) { this.login = login; }
    public AcceptQuoteRequest getAcceptQuote() { return acceptQuote; }
    public void setAcceptQuote(AcceptQuoteRequest acceptQuote) { this.acceptQuote = acceptQuote; }
}
