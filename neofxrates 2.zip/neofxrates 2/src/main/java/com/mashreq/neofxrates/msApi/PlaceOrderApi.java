package com.mashreq.neofxrates.msApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import com.mashreq.neofxrates.dto.PlaceOrderResponse;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.DayOfWeek;
import java.time.LocalDate;

@Service
public class PlaceOrderApi {

    private final ApplicationConfig config;
    private final RestTemplate restTemplate;
    private final ObjectMapper mapper;

    public PlaceOrderApi(ApplicationConfig config, RestTemplate restTemplate, ObjectMapper mapper) {
        this.config = config;
        this.restTemplate = restTemplate;
        this.mapper = mapper;
    }

    public ResponseEntity<PlaceOrderResponse> placeOrder(DirectDealRequest request, String clientOrderId) {
        ObjectNode body = mapper.createObjectNode();
        body.put("coId", clientOrderId);
        body.put("type", "AtBest");
        body.put("symbol", request.getSymbol());
        body.put("side", titleCase(request.getSide()));
        body.put("size", request.getAmount());
        body.put("currency", request.getDealtCurrency());
        body.put("timeInForce", "FOK");
        body.put("valueDate", resolveValueDate(request));
        body.put("org", request.getOrg() == null || request.getOrg().isBlank() ? "NEOFX" : request.getOrg());
        body.put("account", request.getAccount() == null || request.getAccount().isBlank() ? "NEOFX" : request.getAccount());
        body.set("customParameters", mapper.valueToTree(request.getCustomParameters()));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return restTemplate.exchange(
                config.getBaseUrl() + config.getPlaceOrderPath(),
                HttpMethod.POST,
                new HttpEntity<>(body.toString(), headers),
                PlaceOrderResponse.class);
    }

    public String valueDate(DirectDealRequest request) {
        return resolveValueDate(request);
    }

    private String resolveValueDate(DirectDealRequest request) {
        if (request.getValueDate() != null && !request.getValueDate().isBlank()) {
            return request.getValueDate();
        }
        LocalDate date = LocalDate.now();
        int added = 0;
        while (added < 2) {
            date = date.plusDays(1);
            DayOfWeek day = date.getDayOfWeek();
            if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
                added++;
            }
        }
        return date.toString();
    }

    private String titleCase(String value) {
        if (value == null || value.isBlank()) return value;
        return Character.toUpperCase(value.charAt(0)) + value.substring(1).toLowerCase();
    }
}
