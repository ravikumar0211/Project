package com.mashreq.neofxrates.hmac;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.hmac")
@Getter
@Setter
public class IntegralHmacProperties {

    private boolean enabled = true;
    private String username;
    private String secret;
    private String secretEncoding = "utf8";
    private String stripPathPrefix = "/v2";
    private String headers = "date request-line digest";
    private String bodyLineEnding = "lf";
}
