package com.mashreq.neofxrates.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.hmac")
public class HmacProperties {
    private boolean enabled = true;
    private String username;
    private String secret;
    private String secretEncoding = "utf8";
    private String headers = "date request-line digest";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getSecret() { return secret; }
    public void setSecret(String secret) { this.secret = secret; }
    public String getSecretEncoding() { return secretEncoding; }
    public void setSecretEncoding(String secretEncoding) { this.secretEncoding = secretEncoding; }
    public String getHeaders() { return headers; }
    public void setHeaders(String headers) { this.headers = headers; }
}
