package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QueryQuoteResponse {
    private String clOrderId;
    private String requestId;
    private String transactionId;
    private Integer ttl;
    private String event;
    private List<Quote> quotes;

    public String getClOrderId() { return clOrderId; }
    public void setClOrderId(String clOrderId) { this.clOrderId = clOrderId; }
    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
    public Integer getTtl() { return ttl; }
    public void setTtl(Integer ttl) { this.ttl = ttl; }
    public String getEvent() { return event; }
    public void setEvent(String event) { this.event = event; }
    public List<Quote> getQuotes() { return quotes; }
    public void setQuotes(List<Quote> quotes) { this.quotes = quotes; }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Quote {
        private String requestId;
        private String priceType;
        private Integer effectiveTime;
        private String symbol;
        private Integer ttl;
        private String dealtCurrency;
        private String status;
        private String nearValueDate;
        private List<Offer> offers;
        private List<Offer> bids;
        public String getRequestId() { return requestId; }
        public void setRequestId(String requestId) { this.requestId = requestId; }
        public String getPriceType() { return priceType; }
        public void setPriceType(String priceType) { this.priceType = priceType; }
        public Integer getEffectiveTime() { return effectiveTime; }
        public void setEffectiveTime(Integer effectiveTime) { this.effectiveTime = effectiveTime; }
        public String getSymbol() { return symbol; }
        public void setSymbol(String symbol) { this.symbol = symbol; }
        public Integer getTtl() { return ttl; }
        public void setTtl(Integer ttl) { this.ttl = ttl; }
        public String getDealtCurrency() { return dealtCurrency; }
        public void setDealtCurrency(String dealtCurrency) { this.dealtCurrency = dealtCurrency; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getNearValueDate() { return nearValueDate; }
        public void setNearValueDate(String nearValueDate) { this.nearValueDate = nearValueDate; }
        public List<Offer> getOffers() { return offers; }
        public void setOffers(List<Offer> offers) { this.offers = offers; }
        public List<Offer> getBids() { return bids; }
        public void setBids(List<Offer> bids) { this.bids = bids; }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Offer {
        private Integer legType;
        private String quoteId;
        private String type;
        private BigDecimal dealtAmount;
        private BigDecimal settledAmount;
        private String provider;
        private BigDecimal rate;
        private BigDecimal spotRate;
        private BigDecimal forwardPoint;
        private BigDecimal midRate;
        public Integer getLegType() { return legType; }
        public void setLegType(Integer legType) { this.legType = legType; }
        public String getQuoteId() { return quoteId; }
        public void setQuoteId(String quoteId) { this.quoteId = quoteId; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public BigDecimal getDealtAmount() { return dealtAmount; }
        public void setDealtAmount(BigDecimal dealtAmount) { this.dealtAmount = dealtAmount; }
        public BigDecimal getSettledAmount() { return settledAmount; }
        public void setSettledAmount(BigDecimal settledAmount) { this.settledAmount = settledAmount; }
        public String getProvider() { return provider; }
        public void setProvider(String provider) { this.provider = provider; }
        public BigDecimal getRate() { return rate; }
        public void setRate(BigDecimal rate) { this.rate = rate; }
        public BigDecimal getSpotRate() { return spotRate; }
        public void setSpotRate(BigDecimal spotRate) { this.spotRate = spotRate; }
        public BigDecimal getForwardPoint() { return forwardPoint; }
        public void setForwardPoint(BigDecimal forwardPoint) { this.forwardPoint = forwardPoint; }
        public BigDecimal getMidRate() { return midRate; }
        public void setMidRate(BigDecimal midRate) { this.midRate = midRate; }
    }
}
