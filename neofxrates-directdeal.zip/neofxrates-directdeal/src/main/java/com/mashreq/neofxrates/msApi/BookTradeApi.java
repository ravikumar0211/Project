package com.mashreq.neofxrates.msApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class BookTradeApi {
    private final ApplicationConfig config; private final RestTemplate restTemplate; private final ObjectMapper mapper;
    public BookTradeApi(ApplicationConfig config,RestTemplate restTemplate,ObjectMapper mapper){this.config=config;this.restTemplate=restTemplate;this.mapper=mapper;}
    public ResponseEntity<String> bookTrade(DirectDealRequest r,String fillRate,String valueDate,String rate,String spotRate,String rateId,String referenceId){
        ObjectNode b=mapper.createObjectNode();
        b.put("type","Spot"); b.put("channel","1"); b.put("clientRequestId","AcceptFail-"+referenceId+"-"+System.currentTimeMillis());
        b.put("counterparty","NEOFX"); b.put("counterpartyAccount","NEOFX"); b.put("counterpartyTrader","prov"); putNum(b,"coverRate",fillRate);
        b.put("creditMode",2); b.put("customerOrg",r.getCustomerOrg()==null||r.getCustomerOrg().isBlank()?"NEOFX_UAE_CIBG_Regular":r.getCustomerOrg());
        b.put("customerAccount",r.getCustomerAccount()==null||r.getCustomerAccount().isBlank()?"NEOFX_UAE_CIBG_Regular":r.getCustomerAccount());
        b.put("trader","CIBGRegularAPI"); b.put("dealtAmount",r.getAmount()); b.put("dealtIns",r.getDealtCurrency()); b.put("note","Acceptance-Failed");
        putNum(b,"rate",rate); b.put("rateId",rateId); b.put("referenceId",referenceId); b.put("side",r.getSide()); putNum(b,"spotRate",spotRate);
        b.put("stp",true); b.put("symbol",r.getSymbol()); b.put("tradeDate",LocalDate.now().toString()); b.put("valueDate",valueDate);
        ObjectNode c=mapper.createObjectNode(); c.put("CIF","1234553"); c.put("Channel","RBG-SWIFT"); c.put("Settlement","NOSTRO"); c.put("OBDXRef","XX12345"); c.put("OBPRef","xx12345"); c.put("Reversal","TRUE"); b.set("customParameters",c);
        HttpHeaders h=new HttpHeaders(); h.setContentType(MediaType.APPLICATION_JSON);
        return restTemplate.exchange(config.getBaseUrl()+config.getBookTradePath(),HttpMethod.POST,new HttpEntity<>(b.toString(),h),String.class);
    }
    private void putNum(ObjectNode b,String f,String v){if(v==null||v.isBlank()){b.putNull(f);return;}try{b.put(f,new BigDecimal(v));}catch(Exception e){b.put(f,v);}}
}
