package com.mashreq.obms.neofxrates.hmac;

import org.springframework.http.HttpMethod;
import org.springframework.util.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

public class IntegralHmacService {
    private final IntegralHmacProperties properties;

    public IntegralHmacService(IntegralHmacProperties properties) { this.properties = properties; }

    public HmacResponse generateHmacHeaders(HttpMethod method, String requestUrl, String requestBody, String contentType) {
        if (method == null || !StringUtils.hasText(requestUrl)) throw new IllegalArgumentException("HTTP method and request URL are required");
        if (!StringUtils.hasText(properties.getUsername()) || !StringUtils.hasText(properties.getSecret())) {
            throw new IllegalStateException("Integral HMAC is enabled but app.hmac.username/app.hmac.secret are not configured");
        }
        String date = DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now(ZoneOffset.UTC));
        String body = requestBody == null ? "" : requestBody;
        if ("crlf".equalsIgnoreCase(properties.getBodyLineEnding())) body = body.replaceAll("\\r\\n|\\r|\\n", "\\r\\n");
        String digest = sha256Base64(body.getBytes(StandardCharsets.UTF_8));
        URI uri = URI.create(requestUrl);
        String path = uri.getRawPath();
        if (path == null || path.isEmpty()) path = "/";
        if (StringUtils.hasText(uri.getRawQuery())) path += "?" + uri.getRawQuery();
        String prefix = properties.getStripPathPrefix();
        if (StringUtils.hasText(prefix) && path.regionMatches(true, 0, prefix, 0, prefix.length())) path = path.substring(prefix.length());
        if (!path.startsWith("/")) path = "/" + path;
        String requestLine = method.name() + " " + path + " HTTP/1.1";
        String[] headers = StringUtils.hasText(properties.getHeaders())
                ? properties.getHeaders().trim().toLowerCase(Locale.ROOT).split("\\s+")
                : new String[]{"date", "request-line", "digest"};
        StringBuilder signing = new StringBuilder();
        for (String header : headers) {
            if (signing.length() > 0) signing.append('\n');
            switch (header) {
                case "request-line" -> signing.append(requestLine);
                case "date" -> signing.append("date: ").append(date);
                case "digest" -> signing.append("digest: ").append(digest);
                case "content-type" -> signing.append("content-type: ").append(contentType == null ? "" : contentType);
                case "content-length" -> signing.append("content-length: ").append(body.getBytes(StandardCharsets.UTF_8).length);
                default -> signing.append(header).append(": ");
            }
        }
        String signature = hmacSha256Base64(signing.toString(), properties.getSecret(), properties.getSecretEncoding());
        String authorization = String.format(Locale.ROOT,
                "hmac username=\"%s\", algorithm=\"hmac-sha256\", headers=\"%s\", signature=\"%s\"",
                properties.getUsername(), String.join(" ", headers), signature);
        HmacResponse response = new HmacResponse();
        response.setUsername(properties.getUsername()); response.setDate(date); response.setDigest(digest); response.setType("hmac");
        response.setRequestLine(requestLine); response.setSigningString(signing.toString()); response.setSignature(signature); response.setAuthorization(authorization);
        return response;
    }

    private String sha256Base64(byte[] bytes) {
        try { return Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (Exception e) { throw new IllegalStateException("Unable to generate SHA-256 digest", e); }
    }

    private String hmacSha256Base64(String value, String secret, String encoding) {
        try {
            byte[] key = "base64".equalsIgnoreCase(encoding) ? Base64.getDecoder().decode(secret) : secret.getBytes(StandardCharsets.UTF_8);
            Mac mac = Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return Base64.getEncoder().encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException("Unable to generate Integral HMAC signature", e); }
    }
}
