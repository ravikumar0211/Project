package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.LoginRequest;
import com.mashreq.neofxrates.dto.LoginResponse;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class LoginApi {

    private final ApplicationConfig config;
    private final RestTemplate restTemplate;

    public LoginApi(
            ApplicationConfig config,
            RestTemplate restTemplate) {

        this.config = config;
        this.restTemplate = restTemplate;
    }

    public LoginResult login(LoginRequest request) {

        String url =
                config.getBaseUrl()
                        + "/v2/sso/login";

        HttpHeaders headers =
                new HttpHeaders();

        headers.setContentType(
                MediaType.APPLICATION_JSON
        );

        headers.setAccept(
                List.of(MediaType.APPLICATION_JSON)
        );

        HttpEntity<LoginRequest> entity =
                new HttpEntity<>(
                        request,
                        headers
                );

        ResponseEntity<LoginResponse> response =
                restTemplate.exchange(
                        url,
                        HttpMethod.POST,
                        entity,
                        LoginResponse.class
                );

        String ssoToken =
                response.getHeaders()
                        .getFirst("SSO_TOKEN");

        return new LoginResult(
                response.getBody(),
                ssoToken
        );
    }

    public record LoginResult(
            LoginResponse response,
            String ssoToken) {
    }
}

