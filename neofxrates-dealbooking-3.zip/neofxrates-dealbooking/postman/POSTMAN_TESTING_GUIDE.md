# Postman testing — Deal Booking

Swagger UI is not used in this project. Test the REST APIs directly from Postman.

## Flow

1. Call **Accept Quote**.
2. Use the same `requestId` to call **Query Quote**.

## 1. Accept Quote

`POST http://localhost:8080/api/dealbooking/acceptQuote/{{requestId}}`

Body:
```json
{
  "quoteId": "G-6055299-1a08052299b-NEOFX-c8dc252",
  "side": "Buy",
  "symbol": "EUR/USD",
  "dealtCurrency": "EUR",
  "transactionId": "FXI3522946779",
  "clOrderId": "RFQ_AEDEUR0001",
  "rfq": "true",
  "cif": "1234553",
  "refNo": "REF9921102",
  "source": "OBPAY"
}
```

This calls the downstream Postman flow:
`POST /v2/rfs/{{requestId}}`

## 2. Query Quote

`GET http://localhost:8080/api/dealbooking/queryQuote/{{requestId}}`

This calls the downstream Postman flow:
`GET /v2/rfs/{{requestId}}`

The returned JSON contains `data` and `requestBody`, including the supplied Trade Confirmation fields.
