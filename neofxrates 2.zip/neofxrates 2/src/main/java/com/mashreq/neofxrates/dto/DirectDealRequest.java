package com.mashreq.neofxrates.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class DirectDealRequest {

    @NotBlank
    private String symbol;

    @NotBlank
    private String side;

    @NotNull
    @DecimalMin("0.00000001")
    private BigDecimal amount;

    @NotBlank
    private String dealtCurrency;

    private BigDecimal rate;
    private BigDecimal spotRate;
    private String rateId;
    private String referenceId;
    private String customerOrg;
    private String customerAccount;

    private String valueDate;
    private String account = "NEOFX";
    private String org = "NEOFX";
    private String note = "Acceptance-Failed";
    private String counterparty = "NEOFX";
    private String counterpartyAccount = "NEOFX";
    private String counterpartyTrader = "prov";
    private String trader = "CIBGRegularAPI";
    private Integer creditMode = 2;
    private Boolean stp = true;

    // Optional original trade values used by the Book Trade request when supplied by OBPAY.
    private String origTransactionId;
    private String origClOrderId;
    private String origSymbol;
    private String origSide;
    private String origDealtCurrency;
    private BigDecimal origDealtAmount;
    private BigDecimal origRate;
    private BigDecimal origSpotRate;
    private String origCustomerOrg;
    private String origCustomerAccount;

    private Map<String, Object> customParameters = defaultCustomParameters();

    private Map<String, Object> defaultCustomParameters() {
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("CIF", "1234553");
        values.put("Channel", "RBG-SWIFT");
        values.put("Settlement", "NOSTRO");
        values.put("OBDXRef", "XX12345");
        values.put("OBPRef", "xx12345");
        values.put("Reversal", "TRUE");
        return values;
    }
}
