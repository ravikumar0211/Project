package com.mashreq.neofxrates.config;

import com.mashreq.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.neofxrates.hmac.IntegralHmacProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {
    @Bean
    public RestTemplate restTemplate(ApplicationConfig config, IntegralHmacProperties hmacProperties) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(config.getConnectTimeoutMs());
        factory.setReadTimeout(config.getReadTimeoutMs());
        RestTemplate restTemplate = new RestTemplate(factory);
        restTemplate.getInterceptors().add(new IntegralHmacInterceptor(hmacProperties));
        return restTemplate;
    }
}
