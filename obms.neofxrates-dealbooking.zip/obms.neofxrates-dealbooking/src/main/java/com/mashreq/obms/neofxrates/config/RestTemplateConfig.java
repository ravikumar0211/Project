package com.mashreq.obms.neofxrates.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.obms.neofxrates.hmac.IntegralHmacService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {
    @Bean
    public ObjectMapper objectMapper() { return new ObjectMapper(); }

    @Bean
    public IntegralHmacService integralHmacService(IntegralHmacProperties properties) {
        return new IntegralHmacService(properties);
    }

    @Bean
    public RestTemplate restTemplate(IntegralHmacProperties properties, IntegralHmacService hmacService) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getInterceptors().add(new IntegralHmacInterceptor(properties, hmacService));
        return restTemplate;
    }
}
