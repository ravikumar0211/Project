package com.mashreq.neofxrates.msApi;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.neofxrates.hmac.HmacExternalClient;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class AcceptQuoteApi {
    private final HmacExternalClient client;
    private final ObjectMapper mapper;

    public AcceptQuoteApi(HmacExternalClient client, ObjectMapper mapper) {
        this.client = client;
        this.mapper = mapper;
    }

    /** Matches Postman Step 3: POST /v2/rfs/{requestId}. */
    public String accept(AcceptQuoteRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("quoteId", request.quoteId());
        body.put("side", request.side());
        body.put("symbol", request.symbol());
        body.put("dealtCurrency", request.dealtCurrency());
        body.put("transactionId", request.transactionId());
        body.put("clOrderId", request.clOrderId());
        body.put("rfq", request.rfq());
        try {
            return client.post("/v2/rfs/" + request.requestId(), mapper.writeValueAsString(body));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Unable to serialize Accept Quote request", e);
        }
    }
}
