package com.mashreq.neofxrates.exception;

import lombok.Getter;
import org.springframework.http.HttpStatusCode;

@Getter
public class DirectDealException extends RuntimeException {

    private final String step;
    private final HttpStatusCode status;

    public DirectDealException(
            String step,
            HttpStatusCode status,
            String message) {
        super(message);
        this.step = step;
        this.status = status;
    }
}