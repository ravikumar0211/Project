package com.mashreq.neofxrates.dto;

public class DealBookingFlowResponse {
    private String flowStatus;
    private LoginResponse login;
    private AcceptQuoteResponse acceptQuote;
    private QueryQuoteResponse queryQuote;
    private String correlationId;
    public String getFlowStatus() { return flowStatus; }
    public void setFlowStatus(String flowStatus) { this.flowStatus = flowStatus; }
    public LoginResponse getLogin() { return login; }
    public void setLogin(LoginResponse login) { this.login = login; }
    public AcceptQuoteResponse getAcceptQuote() { return acceptQuote; }
    public void setAcceptQuote(AcceptQuoteResponse acceptQuote) { this.acceptQuote = acceptQuote; }
    public QueryQuoteResponse getQueryQuote() { return queryQuote; }
    public void setQueryQuote(QueryQuoteResponse queryQuote) { this.queryQuote = queryQuote; }
    public String getCorrelationId() { return correlationId; }
    public void setCorrelationId(String correlationId) { this.correlationId = correlationId; }
}
