package com.mashreq.neofxrates.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.neofxrates.dto.DealBookingRequest;
import com.mashreq.neofxrates.dto.TradeConfirmationResponse;
import com.mashreq.neofxrates.msApi.AcceptQuoteApi;
import com.mashreq.neofxrates.msApi.QueryQuoteApi;
import org.springframework.stereotype.Service;

@Service
public class DealBookingService {
    private final AcceptQuoteApi acceptQuoteApi;
    private final QueryQuoteApi queryQuoteApi;
    private final ObjectMapper objectMapper;

    public DealBookingService(AcceptQuoteApi acceptQuoteApi, QueryQuoteApi queryQuoteApi, ObjectMapper objectMapper) {
        this.acceptQuoteApi = acceptQuoteApi;
        this.queryQuoteApi = queryQuoteApi;
        this.objectMapper = objectMapper;
    }

    public JsonNode acceptQuote(String requestId, DealBookingRequest request) {
        if (requestId == null || requestId.isBlank()) throw new IllegalArgumentException("requestId must not be blank");
        return readJson(acceptQuoteApi.accept(toAcceptRequest(requestId, request)));
    }

    public JsonNode queryQuote(String requestId) {
        if (requestId == null || requestId.isBlank()) throw new IllegalArgumentException("requestId must not be blank");
        return readJson(queryQuoteApi.query(requestId));
    }

    public TradeConfirmationResponse queryQuoteTyped(String requestId) {
        try {
            return objectMapper.treeToValue(queryQuote(requestId), TradeConfirmationResponse.class);
        } catch (Exception e) {
            throw new IllegalStateException("Query Quote response does not match the supplied Trade Confirmation contract", e);
        }
    }

    private AcceptQuoteRequest toAcceptRequest(String requestId, DealBookingRequest request) {
        return new AcceptQuoteRequest(requestId, request.getQuoteId(), request.getSide(), request.getSymbol(),
                request.getDealtCurrency(), request.getTransactionId(), request.getClOrderId(), request.getRfq());
    }

    private JsonNode readJson(String response) {
        try {
            return objectMapper.readTree(response == null || response.isBlank() ? "{}" : response);
        } catch (Exception e) {
            throw new IllegalStateException("External API returned a non-JSON response", e);
        }
    }
}
