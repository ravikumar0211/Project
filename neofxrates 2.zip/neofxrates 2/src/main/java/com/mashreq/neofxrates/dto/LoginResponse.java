package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoginResponse {

    private String status;

    private Long expiryTime;

    private Long serverUTCTime;

    public LoginResponse() {
    }

    @Override
    public String toString() {
        return "LoginResponse{" +
                "status='" + status + '\'' +
                ", expiryTime=" + expiryTime +
                ", serverUTCTime=" + serverUTCTime +
                '}';
    }
}