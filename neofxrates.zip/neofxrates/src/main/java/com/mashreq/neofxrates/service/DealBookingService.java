package com.mashreq.neofxrates.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.*;
import com.mashreq.neofxrates.entity.DealBookingEntity;
import com.mashreq.neofxrates.exception.ApiException;
import com.mashreq.neofxrates.msApi.AcceptQuoteApi;
import com.mashreq.neofxrates.msApi.LoginApi;
import com.mashreq.neofxrates.msApi.QueryQuoteApi;
import com.mashreq.neofxrates.repository.DealBookingRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DealBookingService {

    private final LoginApi loginApi;
    private final AcceptQuoteApi acceptQuoteApi;
    private final QueryQuoteApi queryQuoteApi;
    private final DealBookingRepository repository;
    private final ObjectMapper objectMapper;
    private final ApplicationConfig config;

    public DealBookingService(
            LoginApi loginApi,
            AcceptQuoteApi acceptQuoteApi,
            QueryQuoteApi queryQuoteApi,
            DealBookingRepository repository,
            ObjectMapper objectMapper,
            ApplicationConfig config) {

        this.loginApi = loginApi;
        this.acceptQuoteApi = acceptQuoteApi;
        this.queryQuoteApi = queryQuoteApi;
        this.repository = repository;
        this.objectMapper = objectMapper;
        this.config = config;
    }

    /**
     * Main business flow:
     *
     * 1. Validate request
     * 2. Login
     * 3. Save initial deal
     * 4. Send RFQ / Accept Quote request
     * 5. Query Quote using returned requestId
     * 6. Return complete flow response
     */
    public ResponseEntity<DealBookingFlowResponse> getcalled(
            DealBookingFlowRequest request) {

        String correlationId =
                "NEOFX-" + System.currentTimeMillis();

        validate(request);

        // Step 1: Login
        LoginApi.LoginResult login =
                callLogin(request.getLogin());

        // Step 2: Save initial request
        DealBookingEntity entity =
                saveInitial(request.getAcceptQuote());

        try {

            // Step 3: RFQ / Accept Quote
            //
            // IMPORTANT:
            // AcceptQuoteApi now uses HMAC authentication automatically.
            // Therefore SSO token is NOT passed here.
            AcceptQuoteResponse accepted =
                    callAcceptQuote(
                            request.getAcceptQuote(),
                            correlationId,
                            login.ssoToken(),
                            entity
                    );

            if (accepted == null
                    || !StringUtils.hasText(accepted.getRequestId())) {

                throw new ApiException(
                        "ACCEPT_QUOTE",
                        HttpStatus.BAD_GATEWAY,
                        "Accept Quote response did not contain requestId"
                );
            }

            // Step 4: Query Quote
            QueryQuoteResponse quote = null;

            int attempts =
                    Math.max(1, config.getQueryAttempts());

            for (int attempt = 1; attempt <= attempts; attempt++) {

                sleep(config.getQueryDelayMs());

                quote =
                        callQueryQuote(
                                accepted.getRequestId(),
                                correlationId,
                                login.ssoToken(),
                                entity
                        );

                if (isQuoteReady(quote)
                        || attempt == attempts) {
                    break;
                }
            }

            // Step 5: Build final response
            DealBookingFlowResponse response =
                    new DealBookingFlowResponse();

            response.setFlowStatus(
                    isQuoteReady(quote)
                            ? "COMPLETED"
                            : "QUERY_COMPLETED_WITHOUT_QUOTE"
            );

            response.setCorrelationId(correlationId);
            response.setLogin(login.response());
            response.setAcceptQuote(accepted);
            response.setQueryQuote(quote);

            return ResponseEntity.ok(response);

        } catch (ApiException ex) {

            entity.setStatus("FAILED");
            entity.setUpdatedAt(LocalDateTime.now());
            repository.save(entity);

            throw ex;

        } catch (Exception ex) {

            entity.setStatus("FAILED");
            entity.setUpdatedAt(LocalDateTime.now());
            repository.save(entity);

            throw new ApiException(
                    "DEAL_BOOKING",
                    HttpStatus.BAD_GATEWAY,
                    rootMessage(ex),
                    ex
            );
        }
    }

    /**
     * Calls Login API.
     */
    private LoginApi.LoginResult callLogin(
            LoginRequest request) {

        try {

            LoginApi.LoginResult result =
                    loginApi.login(request);

            if (result == null
                    || result.response() == null) {

                throw new ApiException(
                        "LOGIN",
                        HttpStatus.BAD_GATEWAY,
                        "Login returned empty response"
                );
            }

            return result;

        } catch (ApiException ex) {

            throw ex;

        } catch (Exception ex) {

            throw new ApiException(
                    "LOGIN",
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Login API: "
                            + rootMessage(ex),
                    ex
            );
        }
    }

    /**
     * Calls RFQ / Accept Quote API.
     *
     * The method keeps the existing service signature so that the
     * rest of this service remains compatible.
     *
     * SSO token is NOT sent to AcceptQuoteApi.
     * HMAC authentication is handled by IntegralHmacInterceptor.
     */
    private AcceptQuoteResponse callAcceptQuote(
            AcceptQuoteRequest request,
            String correlationId,
            String ssoToken,
            DealBookingEntity entity) {

        try {

            /*
             * IMPORTANT:
             *
             * AcceptQuoteApi signature is:
             *
             * acceptQuote(request, correlationId)
             *
             * NOT:
             *
             * acceptQuote(request, correlationId, ssoToken)
             */
            ResponseEntity<AcceptQuoteResponse> response =
                    acceptQuoteApi.acceptQuote(
                            request,
                            correlationId
                    );

            ensure2xx(
                    "ACCEPT_QUOTE",
                    response.getStatusCode()
            );

            AcceptQuoteResponse body =
                    response.getBody();

            if (body == null) {

                throw new ApiException(
                        "ACCEPT_QUOTE",
                        HttpStatus.BAD_GATEWAY,
                        "Accept Quote returned empty response"
                );
            }

            // Save request ID
            entity.setRequestId(
                    body.getRequestId()
            );

            // Save complete response
            entity.setAcceptResponse(
                    toJson(body)
            );

            entity.setStatus("REQUEST_RECEIVED");
            entity.setUpdatedAt(LocalDateTime.now());

            repository.save(entity);

            return body;

        } catch (ApiException ex) {

            throw ex;

        } catch (Exception ex) {

            throw new ApiException(
                    "ACCEPT_QUOTE",
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Accept Quote API: "
                            + rootMessage(ex),
                    ex
            );
        }
    }

    /**
     * Calls Query Quote API.
     *
     * This method retains the existing SSO token parameter because
     * your current QueryQuoteApi accepts:
     *
     * queryQuote(requestId, correlationId, token)
     */
    private QueryQuoteResponse callQueryQuote(
            String requestId,
            String correlationId,
            String token,
            DealBookingEntity entity) {

        try {

            ResponseEntity<QueryQuoteResponse> response =
                    queryQuoteApi.queryQuote(
                            requestId,
                            correlationId,
                            token
                    );

            ensure2xx(
                    "QUERY_QUOTE",
                    response.getStatusCode()
            );

            QueryQuoteResponse body =
                    response.getBody();

            entity.setQueryResponse(
                    toJson(body)
            );

            entity.setStatus(
                    isQuoteReady(body)
                            ? "QUOTE"
                            : "QUERIED"
            );

            entity.setUpdatedAt(
                    LocalDateTime.now()
            );

            repository.save(entity);

            return body;

        } catch (ApiException ex) {

            throw ex;

        } catch (Exception ex) {

            throw new ApiException(
                    "QUERY_QUOTE",
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Query Quote API: "
                            + rootMessage(ex),
                    ex
            );
        }
    }

    /**
     * Determines whether Query Quote returned an actual quote.
     */
    private boolean isQuoteReady(
            QueryQuoteResponse response) {

        if (response == null) {
            return false;
        }

        if (!"QUOTE".equalsIgnoreCase(
                response.getEvent())) {
            return false;
        }

        if (response.getQuotes() == null
                || response.getQuotes().isEmpty()) {
            return false;
        }

        return response.getQuotes()
                .stream()
                .anyMatch(q ->
                        hasItems(q.getOffers())
                                || hasItems(q.getBids())
                );
    }

    /**
     * Checks whether a list contains items.
     */
    private boolean hasItems(List<?> list) {

        return list != null
                && !list.isEmpty();
    }

    /**
     * Saves the initial deal request.
     */
    private DealBookingEntity saveInitial(
            AcceptQuoteRequest request) {

        DealBookingEntity entity =
                new DealBookingEntity();

        entity.setClOrderId(
                request.getClOrderId()
        );

        entity.setSymbol(
                request.getSymbol()
        );

        entity.setAmount(
                request.getAmount()
        );

        entity.setDealtCurrency(
                request.getDealtCurrency()
        );

        entity.setSide(
                request.getSide()
        );

        entity.setStatus("LOGIN_SUCCESS");

        entity.setCreatedAt(
                LocalDateTime.now()
        );

        entity.setUpdatedAt(
                LocalDateTime.now()
        );

        return repository.save(entity);
    }

    /**
     * Validates incoming flow request.
     */
    private void validate(
            DealBookingFlowRequest request) {

        if (request == null
                || request.getLogin() == null
                || request.getAcceptQuote() == null) {

            throw new ApiException(
                    "DEAL_BOOKING",
                    HttpStatus.BAD_REQUEST,
                    "login and acceptQuote are required"
            );
        }

        AcceptQuoteRequest acceptQuote =
                request.getAcceptQuote();

        if (acceptQuote.getClOrderId() == null
                || acceptQuote.getClOrderId().isBlank()) {

            acceptQuote.setClOrderId(
                    "RFQ_" + System.currentTimeMillis()
            );
        }

        if (acceptQuote.getSide() != null) {

            acceptQuote.setSide(
                    acceptQuote.getSide()
                            .trim()
                            .toUpperCase()
            );
        }
    }

    /**
     * Delay before Query Quote.
     */
    private void sleep(int delayMs) {

        if (delayMs <= 0) {
            return;
        }

        try {

            Thread.sleep(delayMs);

        } catch (InterruptedException ex) {

            Thread.currentThread().interrupt();

            throw new ApiException(
                    "QUERY_QUOTE",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Interrupted before Query Quote"
            );
        }
    }

    /**
     * Validates HTTP response status.
     */
    private void ensure2xx(
            String step,
            HttpStatusCode code) {

        if (!code.is2xxSuccessful()) {

            throw new ApiException(
                    step,
                    HttpStatus.BAD_GATEWAY,
                    step
                            + " returned HTTP "
                            + code.value()
            );
        }
    }

    /**
     * Converts an object to JSON for database storage.
     */
    private String toJson(Object value) {

        try {

            return value == null
                    ? null
                    : objectMapper.writeValueAsString(value);

        } catch (JsonProcessingException ex) {

            return String.valueOf(value);
        }
    }

    /**
     * Gets the deepest exception message.
     */
    private String rootMessage(Exception ex) {

        Throwable throwable = ex;

        while (throwable.getCause() != null) {
            throwable = throwable.getCause();
        }

        return throwable.getMessage() == null
                ? throwable.getClass().getSimpleName()
                : throwable.getMessage();
    }
}

