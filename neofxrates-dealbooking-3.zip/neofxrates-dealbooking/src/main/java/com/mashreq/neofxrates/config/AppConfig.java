package com.mashreq.neofxrates.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({HmacProperties.class, ExternalProperties.class})
public class AppConfig {
}
