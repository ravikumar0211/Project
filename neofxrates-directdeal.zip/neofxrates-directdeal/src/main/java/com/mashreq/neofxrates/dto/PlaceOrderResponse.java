package com.mashreq.neofxrates.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
@JsonIgnoreProperties(ignoreUnknown=true)
public class PlaceOrderResponse {
    private String orderId; private String coId; private String status; private String symbol; private String side; private BigDecimal size;
    public String getOrderId(){return orderId;} public void setOrderId(String v){orderId=v;}
    public String getCoId(){return coId;} public void setCoId(String v){coId=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getSymbol(){return symbol;} public void setSymbol(String v){symbol=v;}
    public String getSide(){return side;} public void setSide(String v){side=v;}
    public BigDecimal getSize(){return size;} public void setSize(BigDecimal v){size=v;}
}
