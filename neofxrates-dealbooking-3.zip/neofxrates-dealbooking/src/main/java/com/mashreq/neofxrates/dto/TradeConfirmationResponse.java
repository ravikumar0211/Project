package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;

/** MS -> OBP Trade Confirmation response contract supplied by the user. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record TradeConfirmationResponse(
        Data data,
        RequestBody requestBody
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Data(
            String clOrderId,
            String requestId,
            String transactionId,
            String event,
            Trades trades
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Trades(
            String orderId,
            String tradeId,
            String tradeType,
            String tenor,
            String tradeDate,
            String valueDate,
            boolean maker,
            String orderSide,
            String status,
            String symbol,
            String dealtIns,
            String customerAccount,
            String customerOrg,
            String customerOrgName,
            String trader,
            String counterParty,
            String counterPartyName,
            String cptyLongName,
            String counterPartyAccount,
            String externalRequestId,
            String requestId,
            BigDecimal benchMarkRate,
            String channel,
            long executionTime,
            BigDecimal dealtAmount,
            BigDecimal settledAmount,
            BigDecimal baseAmount,
            BigDecimal termAmount,
            BigDecimal spotRate,
            BigDecimal rate,
            BigDecimal forwardPoints,
            BigDecimal margin,
            boolean midMarket,
            String upi,
            String uti
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record RequestBody(
            String quoteId,
            String side,
            String rfq,
            @JsonProperty("Cif") String cif,
            String refNo,
            String source
    ) {}
}
