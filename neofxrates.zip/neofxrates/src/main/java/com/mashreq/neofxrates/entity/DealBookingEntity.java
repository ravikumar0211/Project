package com.mashreq.neofxrates.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "deal_booking")
public class DealBookingEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String clOrderId;
    private String requestId;
    private String symbol;
    private BigDecimal amount;
    private String dealtCurrency;
    private String side;
    private String status;
    @Lob @Column(columnDefinition = "CLOB") private String acceptResponse;
    @Lob @Column(columnDefinition = "CLOB") private String queryResponse;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    public Long getId() { return id; }
    public String getClOrderId() { return clOrderId; }
    public void setClOrderId(String clOrderId) { this.clOrderId = clOrderId; }
    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getDealtCurrency() { return dealtCurrency; }
    public void setDealtCurrency(String dealtCurrency) { this.dealtCurrency = dealtCurrency; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAcceptResponse() { return acceptResponse; }
    public void setAcceptResponse(String acceptResponse) { this.acceptResponse = acceptResponse; }
    public String getQueryResponse() { return queryResponse; }
    public void setQueryResponse(String queryResponse) { this.queryResponse = queryResponse; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
