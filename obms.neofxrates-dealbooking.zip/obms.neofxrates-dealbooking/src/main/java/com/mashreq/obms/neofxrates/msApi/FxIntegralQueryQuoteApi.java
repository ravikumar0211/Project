package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralQueryQuoteApi {
    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    public ResponseEntity<String> queryQuote(String requestId) {
        String url = applicationConfig.getBaseUrl() + "/v2/rfs/" + requestId;
        return restTemplate.exchange(url, HttpMethod.GET, HttpEntity.EMPTY, String.class);
    }
}
