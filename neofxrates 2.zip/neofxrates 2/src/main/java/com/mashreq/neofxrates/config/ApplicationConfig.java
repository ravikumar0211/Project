package com.mashreq.neofxrates.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class ApplicationConfig {
    private String baseUrl;
    private String loginPath = "/v2/sso/login";
    private String placeOrderPath = "/v2/orders";
    private String queryOrderPath = "/v2/orders/{orderId}";
    private String bookTradePath = "/v2/trades";
    private int connectTimeoutMs = 5000;
    private int readTimeoutMs = 15000;
}
