package com.mashreq.neofxrates.hmac;

import com.mashreq.neofxrates.config.HmacProperties;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZonedDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

@Component
public class HmacSigner {

    private final HmacProperties properties;

    public HmacSigner(HmacProperties properties) {
        this.properties = properties;
    }

    public String utcDate() {
        return ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.RFC_1123_DATE_TIME);
    }

    public String digest(String body) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest((body == null ? "" : body).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to create SHA-256 digest", e);
        }
    }

    public String sign(String signingString) {
        try {
            byte[] keyBytes;
            if ("base64".equalsIgnoreCase(properties.getSecretEncoding())) {
                keyBytes = Base64.getDecoder().decode(properties.getSecret());
            } else {
                keyBytes = properties.getSecret().getBytes(StandardCharsets.UTF_8);
            }

            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keyBytes, "HmacSHA256"));
            return Base64.getEncoder().encodeToString(
                    mac.doFinal(signingString.getBytes(StandardCharsets.UTF_8))
            );
        } catch (Exception e) {
            throw new IllegalStateException("Unable to create HMAC-SHA256 signature", e);
        }
    }

    public String authorization(String signature) {
        String headers = properties.getHeaders().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        return "hmac username=\"" + properties.getUsername()
                + "\", algorithm=\"hmac-sha256\", headers=\"" + headers
                + "\", signature=\"" + signature + "\"";
    }
}
