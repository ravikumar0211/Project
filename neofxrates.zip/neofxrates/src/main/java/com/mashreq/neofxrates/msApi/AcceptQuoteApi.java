package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.neofxrates.dto.AcceptQuoteResponse;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class AcceptQuoteApi {

    private final ApplicationConfig config;
    private final RestTemplate restTemplate;

    public AcceptQuoteApi(
            ApplicationConfig config,
            RestTemplate restTemplate) {

        this.config = config;
        this.restTemplate = restTemplate;
    }

    /**
     * Primary Accept Quote / RFQ method.
     *
     * HMAC authentication is added automatically by
     * IntegralHmacInterceptor.
     */
    public ResponseEntity<AcceptQuoteResponse> acceptQuote(
            AcceptQuoteRequest request,
            String correlationId) {

        String url =
                config.getBaseUrl()
                        + config.getAcceptQuotePath();

        HttpHeaders headers =
                new HttpHeaders();

        headers.setContentType(
                MediaType.APPLICATION_JSON
        );

        headers.setAccept(
                List.of(MediaType.APPLICATION_JSON)
        );

        if (correlationId != null
                && !correlationId.isBlank()) {

            headers.set(
                    "X-Correlation-ID",
                    correlationId
            );
        }

        HttpEntity<AcceptQuoteRequest> entity =
                new HttpEntity<>(
                        request,
                        headers
                );

        return restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                AcceptQuoteResponse.class
        );
    }

    /**
     * Backward-compatible method.
     *
     * Some existing service code still passes the SSO token.
     * The token is intentionally ignored because /v2/rfs
     * uses HMAC authentication.
     */
    public ResponseEntity<AcceptQuoteResponse> acceptQuote(
            AcceptQuoteRequest request,
            String correlationId,
            String ssoToken) {

        return acceptQuote(
                request,
                correlationId
        );
    }
}
