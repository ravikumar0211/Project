package com.mashreq.neofxrates.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** OBP -> MS Deal Booking (Trade Confirmation API) request body. */
public class DealBookingRequest {
    @NotBlank @Size(max = 100)
    private String quoteId;
    @NotBlank @Size(min = 3, max = 4)
    private String side;
    @NotBlank @Size(min = 7, max = 7)
    private String symbol;
    @NotBlank @Size(min = 3, max = 3)
    private String dealtCurrency;
    @NotBlank @Size(max = 50)
    private String transactionId;
    @NotBlank @Size(max = 50)
    private String clOrderId;
    @Size(max = 10)
    private String rfq;
    @NotBlank @Size(max = 20)
    private String cif;
    @NotBlank @Size(max = 35)
    private String refNo;
    @NotBlank @Size(min = 3, max = 15)
    private String source;

    public String getQuoteId() { return quoteId; }
    public void setQuoteId(String quoteId) { this.quoteId = quoteId; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public String getDealtCurrency() { return dealtCurrency; }
    public void setDealtCurrency(String dealtCurrency) { this.dealtCurrency = dealtCurrency; }
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
    public String getClOrderId() { return clOrderId; }
    public void setClOrderId(String clOrderId) { this.clOrderId = clOrderId; }
    public String getRfq() { return rfq; }
    public void setRfq(String rfq) { this.rfq = rfq; }
    public String getCif() { return cif; }
    public void setCif(String cif) { this.cif = cif; }
    public String getRefNo() { return refNo; }
    public void setRefNo(String refNo) { this.refNo = refNo; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
}
