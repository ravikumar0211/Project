package com.mashreq.neofxrates.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class DirectDealRequest {
    @NotBlank private String symbol;
    @NotBlank private String side;
    @NotNull @DecimalMin("0.00000001") private BigDecimal amount;
    @NotBlank private String dealtCurrency;
    private BigDecimal rate;
    private BigDecimal spotRate;
    private String rateId;
    private String referenceId;
    private String customerOrg;
    private String customerAccount;
    public String getSymbol(){return symbol;} public void setSymbol(String v){symbol=v;}
    public String getSide(){return side;} public void setSide(String v){side=v;}
    public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
    public String getDealtCurrency(){return dealtCurrency;} public void setDealtCurrency(String v){dealtCurrency=v;}
    public BigDecimal getRate(){return rate;} public void setRate(BigDecimal v){rate=v;}
    public BigDecimal getSpotRate(){return spotRate;} public void setSpotRate(BigDecimal v){spotRate=v;}
    public String getRateId(){return rateId;} public void setRateId(String v){rateId=v;}
    public String getReferenceId(){return referenceId;} public void setReferenceId(String v){referenceId=v;}
    public String getCustomerOrg(){return customerOrg;} public void setCustomerOrg(String v){customerOrg=v;}
    public String getCustomerAccount(){return customerAccount;} public void setCustomerAccount(String v){customerAccount=v;}
}
