package com.mashreq.neofxrates.entity;
import jakarta.persistence.*; import java.math.BigDecimal; import java.time.LocalDateTime;
@Entity @Table(name="deal_booking")
public class DealBookingEntity {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String clientOrderId; private String orderId; private String symbol; private BigDecimal amount; private String dealtCurrency; private String side; private String status;
 @Lob @Column(columnDefinition="CLOB") private String placeOrderResponse;
 @Lob @Column(columnDefinition="CLOB") private String queryOrderResponse;
 @Lob @Column(columnDefinition="CLOB") private String bookTradeResponse;
 private LocalDateTime createdAt; private LocalDateTime updatedAt;
 public Long getId(){return id;} public String getClientOrderId(){return clientOrderId;} public void setClientOrderId(String v){clientOrderId=v;} public String getOrderId(){return orderId;} public void setOrderId(String v){orderId=v;} public String getSymbol(){return symbol;} public void setSymbol(String v){symbol=v;} public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;} public String getDealtCurrency(){return dealtCurrency;} public void setDealtCurrency(String v){dealtCurrency=v;} public String getSide(){return side;} public void setSide(String v){side=v;} public String getStatus(){return status;} public void setStatus(String v){status=v;} public String getPlaceOrderResponse(){return placeOrderResponse;} public void setPlaceOrderResponse(String v){placeOrderResponse=v;} public String getQueryOrderResponse(){return queryOrderResponse;} public void setQueryOrderResponse(String v){queryOrderResponse=v;} public String getBookTradeResponse(){return bookTradeResponse;} public void setBookTradeResponse(String v){bookTradeResponse=v;} public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;} public LocalDateTime getUpdatedAt(){return updatedAt;} public void setUpdatedAt(LocalDateTime v){updatedAt=v;}
}
