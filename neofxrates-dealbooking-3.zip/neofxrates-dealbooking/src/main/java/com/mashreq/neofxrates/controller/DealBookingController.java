package com.mashreq.neofxrates.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.mashreq.neofxrates.dto.DealBookingRequest;
import com.mashreq.neofxrates.dto.TradeConfirmationResponse;
import com.mashreq.neofxrates.service.DealBookingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dealbooking")
public class DealBookingController {
    private final DealBookingService service;

    public DealBookingController(DealBookingService service) {
        this.service = service;
    }

    /** OBP -> MS: Accept Quote. requestId is the server-generated RFS id used in the downstream URL. */
    @PostMapping("/acceptQuote/{requestId}")
    public ResponseEntity<JsonNode> acceptQuote(
            @PathVariable String requestId,
            @Valid @RequestBody DealBookingRequest request) {
        return ResponseEntity.ok(service.acceptQuote(requestId, request));
    }

    /** OBP -> MS: Query Quote / Trade Confirmation using the server-generated RFS id. */
    @GetMapping("/queryQuote/{requestId}")
    public ResponseEntity<TradeConfirmationResponse> queryQuote(@PathVariable String requestId) {
        return ResponseEntity.ok(service.queryQuoteTyped(requestId));
    }
}
