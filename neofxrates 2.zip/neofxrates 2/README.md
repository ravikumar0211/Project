# NEOFX Direct Deal API

This project is implemented from the supplied `obms-neofxrates-api` reference project and the supplied Direct Deal Postman workflow.

## External API sequence

```text
1. POST /v2/sso/login
       |
       | successful login response
       v
2. POST /v2/orders
       |
       | orderId from Place Order response
       v
3. GET /v2/orders/{orderId}
       |
       | status must be FILLED
       | averagePrice is used as coverRate/fillRate
       v
4. POST /v2/trades
       |
       v
   Book Trade response
```

There is **no SSO token handling**. The login response is not converted into a token and no `SSO_TOKEN` header is sent. `IntegralHmacInterceptor` independently signs all four downstream requests.

## Internal API

```http
POST http://localhost:8080/directdeal/execute
Content-Type: application/json
```

Example request:

```json
{
  "login": {
    "user": "prov",
    "pass": "Forex1234$",
    "org": "NEOFX"
  },
  "directDeal": {
    "symbol": "EUR/USD",
    "side": "BUY",
    "amount": 1000,
    "dealtCurrency": "EUR",
    "customerOrg": "NEOFX_UAE_CIBG_Regular",
    "customerAccount": "NEOFX_UAE_CIBG_Regular",
    "origTransactionId": "FXI3527357861",
    "origClOrderId": "RFQ_1789552740935",
    "origSymbol": "EUR/USD",
    "origSide": "BUY",
    "origDealtCurrency": "EUR",
    "origRate": 1.18857,
    "origSpotRate": 1.18857,
    "customParameters": {
      "CIF": "1234553",
      "Channel": "RBG-SWIFT",
      "Settlement": "NOSTRO",
      "OBDXRef": "XX12345",
      "OBPRef": "xx12345",
      "Reversal": "TRUE"
    }
  }
}
```

The service obtains `orderId` from Place Order, passes it to Query Order, verifies `FILLED`, takes `averagePrice`, and then constructs Book Trade using the Postman field names and values.

## HMAC

HMAC follows the supplied reference implementation:

- RFC-1123 UTC `Date`
- raw Base64 SHA-256 `Digest` with no `SHA-256=` prefix
- `type: hmac`
- signed headers: `date request-line digest`
- `/v2` removed from the signed request line
- request line: `METHOD /path HTTP/1.1`
- HMAC-SHA256 and Base64 signature
- UTF-8 secret by default
- `Authorization` uses `username="..."`

## YAML configuration

The three YAML files follow the supplied reference project's profiles:

- `application.yaml`
- `application-local.yaml`
- `application-test.yaml`

The Direct Deal-specific downstream paths and HMAC settings are retained in the local/test profiles.

## Swagger

Swagger/OpenAPI UI is not included.

## Build

```bash
./mvnw clean test
./mvnw spring-boot:run
```

If Maven Wrapper is not already cached, Maven may need internet access once to download its distribution.
