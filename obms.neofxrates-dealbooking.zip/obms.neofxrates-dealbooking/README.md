# obms-neofxrates-dealbooking-api

Package: `com.mashreq.obms.neofxrates`

This service contains ONLY the Post Trade STP Deal Booking flow from the supplied Postman collection:

```text
OBPAY
  |
  | POST /dealbooking/acceptQuote
  v
DealBookingController
  |
  v
DealBookingService
  |
  +-- 1. Accept Quote
  |      POST /v2/rfs/{requestId}
  |
  +-- 2. Query Quote
         GET /v2/rfs/{requestId}
               |
               v
      DealBookingResponseMapper
               |
               v
      ObpayDealBookingResponse
               |
               v
             OBPAY
```

No Request Quote, Login/SSO, Indicative FX, repository/database, or STP polling workflow is included.
