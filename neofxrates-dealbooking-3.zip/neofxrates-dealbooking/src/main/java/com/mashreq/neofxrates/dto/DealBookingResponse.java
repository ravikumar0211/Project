package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.databind.JsonNode;

public record DealBookingResponse(
        String workflow,
        String requestId,
        String quoteId,
        JsonNode acceptQuoteResponse,
        JsonNode queryQuoteResponse
) {}
