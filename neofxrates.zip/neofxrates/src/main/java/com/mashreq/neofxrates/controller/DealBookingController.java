package com.mashreq.neofxrates.controller;

import com.mashreq.neofxrates.dto.DealBookingFlowRequest;
import com.mashreq.neofxrates.dto.DealBookingFlowResponse;
import com.mashreq.neofxrates.service.DealBookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/dealbooking")
@Tag(name = "Deal Booking", description = "Single controller entry point for Login -> Accept Quote -> Query Quote")
public class DealBookingController {
    private final DealBookingService service;
    public DealBookingController(DealBookingService service) { this.service = service; }

    @PostMapping
    @Operation(summary = "Execute Deal Booking workflow", description = "Internally calls Login, then Accept Quote, then Query Quote using the requestId returned by Accept Quote.")
    public ResponseEntity<DealBookingFlowResponse> dealBooking(@Valid @RequestBody DealBookingFlowRequest request) {
        return service.getcalled(request);
    }
}
