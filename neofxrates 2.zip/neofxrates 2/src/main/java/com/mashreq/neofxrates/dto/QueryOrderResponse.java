package com.mashreq.neofxrates.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown=true)
public class QueryOrderResponse {
    private String orderId;
    private String coId;
    private String status;
    private String symbol;
    private String side;
    private BigDecimal size;
    private BigDecimal cumQty;
    private BigDecimal averagePrice;
    private String tradeDate;
    private List<Object> fills;

}
