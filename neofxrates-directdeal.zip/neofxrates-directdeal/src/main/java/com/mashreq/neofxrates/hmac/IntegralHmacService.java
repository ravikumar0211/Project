package com.mashreq.neofxrates.hmac;

import org.springframework.http.HttpMethod;
import org.springframework.util.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;

public class IntegralHmacService {

    private final IntegralHmacProperties properties;

    public IntegralHmacService(IntegralHmacProperties properties) {
        this.properties = properties;
    }

    public HmacResponse generateHmacHeaders(
            HttpMethod method,
            String requestUrl,
            String requestBody,
            String contentType) {

        if (method == null) {
            throw new IllegalArgumentException("HTTP method is required");
        }
        if (!StringUtils.hasText(requestUrl)) {
            throw new IllegalArgumentException("Request URL is required");
        }
        if (!StringUtils.hasText(properties.getUsername())
                || !StringUtils.hasText(properties.getSecret())) {
            throw new IllegalStateException(
                    "Integral HMAC is enabled but app.hmac.username/app.hmac.secret are not configured");
        }

        String date = DateTimeFormatter.RFC_1123_DATE_TIME
                .format(ZonedDateTime.now(ZoneOffset.UTC));

        String body = requestBody == null ? "" : requestBody;
        if ("crlf".equalsIgnoreCase(properties.getBodyLineEnding())) {
            body = body.replaceAll("\\r\\n|\\r|\\n", "\\r\\n");
        }

        String digest = sha256Base64(body.getBytes(StandardCharsets.UTF_8));

        URI uri = URI.create(requestUrl);
        String pathForSigning = getPathWithQuery(uri);

        String stripPathPrefix = properties.getStripPathPrefix();
        if (StringUtils.hasText(stripPathPrefix)
                && pathForSigning.regionMatches(
                true, 0, stripPathPrefix, 0, stripPathPrefix.length())) {
            pathForSigning = pathForSigning.substring(stripPathPrefix.length());
        }

        if (!pathForSigning.startsWith("/")) {
            pathForSigning = "/" + pathForSigning;
        }

        String requestLine = method.name() + " " + pathForSigning + " HTTP/1.1";
        String[] headersToSign = parseHeaders(properties.getHeaders());

        StringBuilder signingString = new StringBuilder();
        for (int i = 0; i < headersToSign.length; i++) {
            if (i > 0) {
                signingString.append('\n');
            }

            String header = headersToSign[i];

            switch (header) {
                case "request-line" -> signingString.append(requestLine);
                case "date" -> signingString.append("date: ").append(date);
                case "digest" -> signingString.append("digest: ").append(digest);
                case "content-type" -> signingString.append("content-type: ")
                        .append(contentType == null ? "" : contentType);
                case "content-length" -> signingString.append("content-length: ")
                        .append(body.getBytes(StandardCharsets.UTF_8).length);
                default -> signingString.append(header).append(": ");
            }
        }

        String signature = hmacSha256Base64(
                signingString.toString(),
                properties.getSecret(),
                properties.getSecretEncoding());

        String authorization = String.format(
                Locale.ROOT,
                "hmac username=\"%s\", algorithm=\"hmac-sha256\", headers=\"%s\", signature=\"%s\"",
                properties.getUsername(),
                String.join(" ", headersToSign),
                signature);

        HmacResponse response = new HmacResponse();
        response.setUsername(properties.getUsername());
        response.setDate(date);
        response.setDigest(digest);
        response.setType("hmac");
        response.setRequestLine(requestLine);
        response.setSigningString(signingString.toString());
        response.setSignature(signature);
        response.setAuthorization(authorization);

        return response;
    }

    private String[] parseHeaders(String configuredHeaders) {
        if (!StringUtils.hasText(configuredHeaders)) {
            return new String[]{"date", "request-line", "digest"};
        }
        return configuredHeaders.trim().toLowerCase(Locale.ROOT).split("\\s+");
    }

    private String getPathWithQuery(URI uri) {
        String path = uri.getRawPath();
        if (path == null || path.isEmpty()) {
            path = "/";
        }

        String query = uri.getRawQuery();
        return query == null || query.isEmpty()
                ? path
                : path + "?" + query;
    }

    private String sha256Base64(byte[] body) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return Base64.getEncoder().encodeToString(md.digest(body));
        } catch (Exception ex) {
            throw new IllegalStateException(
                    "Unable to generate SHA-256 digest", ex);
        }
    }

    private String hmacSha256Base64(
            String value,
            String secret,
            String encoding) {

        try {
            byte[] keyBytes;
            if ("base64".equalsIgnoreCase(encoding)) {
                keyBytes = Base64.getDecoder().decode(secret);
            } else {
                keyBytes = secret.getBytes(StandardCharsets.UTF_8);
            }

            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keyBytes, "HmacSHA256"));

            byte[] result = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(result);
        } catch (Exception ex) {
            throw new IllegalStateException(
                    "Unable to generate Integral HMAC signature", ex);
        }
    }
}
