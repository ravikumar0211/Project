package com.mashreq.neofxrates.exception;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.dto.ApiErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.OffsetDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> validation(MethodArgumentNotValidException ex,
                                                        HttpServletRequest request) {
        String message = ex.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .orElse("Validation failed");

        return ResponseEntity.badRequest().body(
                new ApiErrorResponse(OffsetDateTime.now(), 400, "Bad Request", message, request.getRequestURI())
        );
    }

    @ExceptionHandler(ExternalApiException.class)
    public ResponseEntity<?> external(ExternalApiException ex, HttpServletRequest request) {
        try {
            JsonNode body = objectMapper.readTree(ex.getResponseBody());
            return ResponseEntity.status(ex.getStatus()).body(body);
        } catch (Exception ignored) {
            return ResponseEntity.status(ex.getStatus()).body(
                    new ApiErrorResponse(OffsetDateTime.now(), ex.getStatus(),
                            "External API Error", ex.getResponseBody(), request.getRequestURI())
            );
        }
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class})
    public ResponseEntity<ApiErrorResponse> badRequest(RuntimeException ex,
                                                          HttpServletRequest request) {
        return ResponseEntity.badRequest().body(
                new ApiErrorResponse(OffsetDateTime.now(), 400, "Bad Request",
                        ex.getMessage(), request.getRequestURI())
        );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> generic(Exception ex, HttpServletRequest request) {
        return ResponseEntity.internalServerError().body(
                new ApiErrorResponse(OffsetDateTime.now(), 500, "Internal Server Error",
                        ex.getMessage(), request.getRequestURI())
        );
    }
}
