package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.service.DealBookingService;
import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.ObpayDealBookingResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dealbooking")
@RequiredArgsConstructor
public class DealBookingController {
    private final DealBookingService dealBookingService;

    @PostMapping("/acceptQuote")
    public ResponseEntity<ObpayDealBookingResponse> acceptQuote(@RequestBody DealBookingRequest request) {
        return ResponseEntity.ok(dealBookingService.acceptQuoteAndQuery(request));
    }
}
