package com.mashreq.neofxrates.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DirectDealFlowRequest {
    @NotNull @Valid private LoginRequest login;
    @NotNull @Valid private DirectDealRequest directDeal;

}
