package com.mashreq.neofxrates.msApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.BookTradeResponse;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class BookTradeApi {

    private final ApplicationConfig config;
    private final RestTemplate restTemplate;
    private final ObjectMapper mapper;

    public BookTradeApi(ApplicationConfig config, RestTemplate restTemplate, ObjectMapper mapper) {
        this.config = config;
        this.restTemplate = restTemplate;
        this.mapper = mapper;
    }

    public ResponseEntity<BookTradeResponse> bookTrade(
            DirectDealRequest request,
            String clientOrderId,
            String fillRate,
            String valueDate) {

        String clientRequestId = "AcceptFail-"
                + (request.getOrigTransactionId() == null || request.getOrigTransactionId().isBlank()
                ? clientOrderId : request.getOrigTransactionId())
                + "-" + System.currentTimeMillis();

        String rate = request.getOrigRate() != null
                ? request.getOrigRate().toPlainString()
                : request.getRate() != null ? request.getRate().toPlainString() : fillRate;

        String spotRate = request.getOrigSpotRate() != null
                ? request.getOrigSpotRate().toPlainString()
                : request.getSpotRate() != null ? request.getSpotRate().toPlainString() : rate;

        String rateId = firstText(request.getOrigClOrderId(), request.getRateId(), clientOrderId);
        String referenceId = firstText(request.getOrigTransactionId(), request.getReferenceId(), clientOrderId);
        String symbol = firstText(request.getOrigSymbol(), request.getSymbol());
        String side = firstText(request.getOrigSide(), request.getSide());
        String dealtCurrency = firstText(request.getOrigDealtCurrency(), request.getDealtCurrency());
        BigDecimal dealtAmount = request.getOrigDealtAmount() != null
                ? request.getOrigDealtAmount() : request.getAmount();
        String customerOrg = firstText(request.getOrigCustomerOrg(), request.getCustomerOrg(), "NEOFX_UAE_CIBG_Regular");
        String customerAccount = firstText(request.getOrigCustomerAccount(), request.getCustomerAccount(), "NEOFX_UAE_CIBG_Regular");

        ObjectNode body = mapper.createObjectNode();
        body.put("type", "Spot");
        body.put("channel", "1");
        body.put("clientRequestId", clientRequestId);
        body.put("counterparty", firstText(request.getCounterparty(), "NEOFX"));
        body.put("counterpartyAccount", firstText(request.getCounterpartyAccount(), "NEOFX"));
        body.put("counterpartyTrader", firstText(request.getCounterpartyTrader(), "prov"));
        putNumber(body, "coverRate", fillRate);
        body.put("creditMode", request.getCreditMode() == null ? 2 : request.getCreditMode());
        body.put("customerOrg", customerOrg);
        body.put("customerAccount", customerAccount);
        body.put("trader", firstText(request.getTrader(), "CIBGRegularAPI"));
        body.put("dealtAmount", dealtAmount);
        body.put("dealtIns", dealtCurrency);
        body.put("note", firstText(request.getNote(), "Acceptance-Failed"));
        putNumber(body, "rate", rate);
        body.put("rateId", rateId);
        body.put("referenceId", referenceId);
        body.put("side", side);
        putNumber(body, "spotRate", spotRate);
        body.put("stp", request.getStp() == null || request.getStp());
        body.put("symbol", symbol);
        body.put("tradeDate", LocalDate.now().toString());
        body.put("valueDate", valueDate);
        body.set("customParameters", mapper.valueToTree(request.getCustomParameters()));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return restTemplate.exchange(
                config.getBaseUrl() + config.getBookTradePath(),
                HttpMethod.POST,
                new HttpEntity<>(body.toString(), headers),
                BookTradeResponse.class);
    }

    private String firstText(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value;
        }
        return null;
    }

    private void putNumber(ObjectNode body, String field, String value) {
        if (value == null || value.isBlank()) {
            body.putNull(field);
            return;
        }
        try {
            body.put(field, new BigDecimal(value));
        } catch (NumberFormatException ex) {
            body.put(field, value);
        }
    }
}
