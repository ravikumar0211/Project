package com.mashreq.obms.neofxrates.controller;

import com.mashreq.obms.neofxrates.dealbooking.service.DealBookingService;
import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.dto.ObpayDealBookingResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DealBookingController.class)
class DealBookingControllerTest {
    @Autowired MockMvc mockMvc;
    @MockitoBean DealBookingService service;

    @Test void exposesAcceptQuoteEndpoint() throws Exception {
        when(service.acceptQuoteAndQuery(any(DealBookingRequest.class)))
                .thenReturn(ObpayDealBookingResponse.builder().status("SUCCESS").accepted(true).build());
        mockMvc.perform(post("/dealbooking/acceptQuote")
                        .contentType("application/json")
                        .content("{\"requestId\":\"REQ1\",\"quoteId\":\"Q1\",\"side\":\"BUY\",\"symbol\":\"EUR/USD\",\"dealtCurrency\":\"EUR\",\"transactionId\":\"TX1\",\"clOrderId\":\"CL1\",\"rfq\":true}"))
                .andExpect(status().isOk());
    }
}
