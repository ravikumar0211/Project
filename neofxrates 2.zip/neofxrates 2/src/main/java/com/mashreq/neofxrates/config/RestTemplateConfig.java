package com.mashreq.neofxrates.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.hmac.IntegralHmacInterceptor;
import com.mashreq.neofxrates.hmac.IntegralHmacProperties;
import com.mashreq.neofxrates.hmac.IntegralHmacService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public IntegralHmacService integralHmacService(
            IntegralHmacProperties properties) {

        return new IntegralHmacService(properties);
    }

    @Bean
    public RestTemplate restTemplate(
            ApplicationConfig config,
            IntegralHmacProperties properties,
            IntegralHmacService hmacService) {

        SimpleClientHttpRequestFactory factory =
                new SimpleClientHttpRequestFactory();

        factory.setConnectTimeout(
                config.getConnectTimeoutMs());

        factory.setReadTimeout(
                config.getReadTimeoutMs());

        RestTemplate restTemplate =
                new RestTemplate(factory);

        restTemplate.getInterceptors().add(
                new IntegralHmacInterceptor(
                        properties,
                        hmacService));

        return restTemplate;
    }
}