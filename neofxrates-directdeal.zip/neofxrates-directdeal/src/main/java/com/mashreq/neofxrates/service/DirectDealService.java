package com.mashreq.neofxrates.service;

import com.mashreq.neofxrates.dto.DirectDealFlowRequest;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import com.mashreq.neofxrates.dto.LoginResponse;
import com.mashreq.neofxrates.dto.PlaceOrderResponse;
import com.mashreq.neofxrates.dto.QueryOrderResponse;
import com.mashreq.neofxrates.msApi.BookTradeApi;
import com.mashreq.neofxrates.msApi.LoginApi;
import com.mashreq.neofxrates.msApi.PlaceOrderApi;
import com.mashreq.neofxrates.msApi.QueryOrderApi;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class DirectDealService {

    private final LoginApi loginApi;
    private final PlaceOrderApi placeOrderApi;
    private final QueryOrderApi queryOrderApi;
    private final BookTradeApi bookTradeApi;

    public DirectDealService(
            LoginApi loginApi,
            PlaceOrderApi placeOrderApi,
            QueryOrderApi queryOrderApi,
            BookTradeApi bookTradeApi) {
        this.loginApi = loginApi;
        this.placeOrderApi = placeOrderApi;
        this.queryOrderApi = queryOrderApi;
        this.bookTradeApi = bookTradeApi;
    }

    /**
     * Complete external API orchestration:
     *
     * 1. Login - HMAC authenticated
     * 2. Place Order - HMAC authenticated
     * 3. Query Order using orderId returned by Place Order
     * 4. Book Trade using the fill price returned by Query Order
     *
     * The login response is deliberately NOT converted into an SSO token.
     * Every outbound call is independently HMAC authenticated by the RestTemplate interceptor.
     */
    public ResponseEntity<String> execute(DirectDealFlowRequest flow) {

        // 1. LOGIN
        ResponseEntity<LoginResponse> login =
                loginApi.login(flow.getLogin());
        ensure2xx("LOGIN", login);

        // 2. PLACE ORDER
        DirectDealRequest request = flow.getDirectDeal();
        String clientOrderId = "DIRECT_" + System.currentTimeMillis();

        ResponseEntity<PlaceOrderResponse> placed =
                placeOrderApi.placeOrder(request, clientOrderId);
        ensure2xx("PLACE_ORDER", placed);

        PlaceOrderResponse placeOrderResponse = placed.getBody();
        if (placeOrderResponse == null
                || placeOrderResponse.getOrderId() == null
                || placeOrderResponse.getOrderId().isBlank()) {
            throw new IllegalStateException(
                    "PLACE_ORDER response does not contain orderId");
        }

        String orderId = placeOrderResponse.getOrderId();

        // 3. QUERY ORDER
        ResponseEntity<QueryOrderResponse[]> queried =
                queryOrderApi.queryOrder(orderId);
        ensure2xx("QUERY_ORDER", queried);

        QueryOrderResponse[] orders = queried.getBody();
        QueryOrderResponse order =
                orders == null || orders.length == 0 ? null : orders[0];

        if (order == null) {
            throw new IllegalStateException(
                    "QUERY_ORDER returned no order for orderId=" + orderId);
        }

        if (order.getAveragePrice() == null) {
            throw new IllegalStateException(
                    "QUERY_ORDER response does not contain averagePrice");
        }

        if (order.getStatus() == null
                || !"FILLED".equalsIgnoreCase(order.getStatus())) {
            throw new IllegalStateException(
                    "QUERY_ORDER order is not FILLED. Current status="
                            + order.getStatus()
                            + ". Book Trade was not called.");
        }

        // 4. BOOK TRADE
        String fillRate = order.getAveragePrice().toPlainString();

        String rate = request.getRate() == null
                ? fillRate
                : request.getRate().toPlainString();

        String spotRate = request.getSpotRate() == null
                ? rate
                : request.getSpotRate().toPlainString();

        String rateId = request.getRateId() == null
                || request.getRateId().isBlank()
                ? clientOrderId
                : request.getRateId();

        String referenceId = request.getReferenceId() == null
                || request.getReferenceId().isBlank()
                ? clientOrderId
                : request.getReferenceId();

        ResponseEntity<String> book =
                bookTradeApi.bookTrade(
                        request,
                        fillRate,
                        placeOrderApi.valueDate(),
                        rate,
                        spotRate,
                        rateId,
                        referenceId);

        ensure2xx("BOOK_TRADE", book);

        return ResponseEntity
                .status(book.getStatusCode())
                .headers(book.getHeaders())
                .body(book.getBody());
    }

    private void ensure2xx(String step, ResponseEntity<?> response) {
        if (response == null || !response.getStatusCode().is2xxSuccessful()) {
            throw new IllegalStateException(
                    step + " returned HTTP "
                            + (response == null
                            ? "null"
                            : response.getStatusCode()));
        }
    }
}
