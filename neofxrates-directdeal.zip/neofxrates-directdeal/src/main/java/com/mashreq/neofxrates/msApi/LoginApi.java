package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.LoginRequest;
import com.mashreq.neofxrates.dto.LoginResponse;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class LoginApi {
    private final ApplicationConfig config;
    private final RestTemplate restTemplate;
    public LoginApi(ApplicationConfig config, RestTemplate restTemplate){this.config=config;this.restTemplate=restTemplate;}
    public ResponseEntity<LoginResponse> login(LoginRequest request){
        String url=config.getBaseUrl()+config.getLoginPath();
        // No SSO_TOKEN is read. HMAC interceptor signs this request.
        return restTemplate.exchange(url,HttpMethod.POST,new HttpEntity<>(request),LoginResponse.class);
    }
}
