package com.mashreq.neofxrates.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
public class ApplicationConfig {
    private String baseUrl;
    private String loginPath = "/v2/sso/login";
    private String placeOrderPath = "/v2/orders";
    private String queryOrderPath = "/v2/orders/{orderId}";
    private String bookTradePath = "/v2/trades";
    private int connectTimeoutMs = 5000;
    private int readTimeoutMs = 15000;
    public String getBaseUrl(){return baseUrl;} public void setBaseUrl(String v){baseUrl=v;}
    public String getLoginPath(){return loginPath;} public void setLoginPath(String v){loginPath=v;}
    public String getPlaceOrderPath(){return placeOrderPath;} public void setPlaceOrderPath(String v){placeOrderPath=v;}
    public String getQueryOrderPath(){return queryOrderPath;} public void setQueryOrderPath(String v){queryOrderPath=v;}
    public String getBookTradePath(){return bookTradePath;} public void setBookTradePath(String v){bookTradePath=v;}
    public int getConnectTimeoutMs(){return connectTimeoutMs;} public void setConnectTimeoutMs(int v){connectTimeoutMs=v;}
    public int getReadTimeoutMs(){return readTimeoutMs;} public void setReadTimeoutMs(int v){readTimeoutMs=v;}
}
