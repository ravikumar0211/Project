package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcceptQuoteRequest {
    @NotBlank private String clOrderId;
    @NotBlank private String symbol;
    @NotNull @DecimalMin("0.000001") private BigDecimal amount;
    @NotBlank private String dealtCurrency;
    @NotBlank private String side;
    @NotNull private Boolean rfq;
    @NotNull private Long expiry;
    @NotBlank private String priceType;
    @NotBlank private String customerAccount;
    @NotBlank private String customerOrg;
    @NotBlank private String nearValueDate;
    private Map<String, Object> customParameters;

    public String getClOrderId() { return clOrderId; }
    public void setClOrderId(String clOrderId) { this.clOrderId = clOrderId; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getDealtCurrency() { return dealtCurrency; }
    public void setDealtCurrency(String dealtCurrency) { this.dealtCurrency = dealtCurrency; }
    public String getSide() { return side; }
    public void setSide(String side) { this.side = side; }
    public Boolean getRfq() { return rfq; }
    public void setRfq(Boolean rfq) { this.rfq = rfq; }
    public Long getExpiry() { return expiry; }
    public void setExpiry(Long expiry) { this.expiry = expiry; }
    public String getPriceType() { return priceType; }
    public void setPriceType(String priceType) { this.priceType = priceType; }
    public String getCustomerAccount() { return customerAccount; }
    public void setCustomerAccount(String customerAccount) { this.customerAccount = customerAccount; }
    public String getCustomerOrg() { return customerOrg; }
    public void setCustomerOrg(String customerOrg) { this.customerOrg = customerOrg; }
    public String getNearValueDate() { return nearValueDate; }
    public void setNearValueDate(String nearValueDate) { this.nearValueDate = nearValueDate; }
    public Map<String, Object> getCustomParameters() { return customParameters; }
    public void setCustomParameters(Map<String, Object> customParameters) { this.customParameters = customParameters; }
}
