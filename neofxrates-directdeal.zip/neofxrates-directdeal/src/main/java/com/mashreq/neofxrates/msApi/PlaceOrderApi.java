package com.mashreq.neofxrates.msApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import com.mashreq.neofxrates.dto.PlaceOrderResponse;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.time.DayOfWeek;
import java.time.LocalDate;

@Service
public class PlaceOrderApi {
    private final ApplicationConfig config; private final RestTemplate restTemplate; private final ObjectMapper mapper;
    public PlaceOrderApi(ApplicationConfig config,RestTemplate restTemplate,ObjectMapper mapper){this.config=config;this.restTemplate=restTemplate;this.mapper=mapper;}
    public ResponseEntity<PlaceOrderResponse> placeOrder(DirectDealRequest r,String clientOrderId){
        ObjectNode b=mapper.createObjectNode();
        b.put("coId",clientOrderId); b.put("type","AtBest"); b.put("symbol",r.getSymbol());
        b.put("side",titleCase(r.getSide())); b.put("size",r.getAmount()); b.put("currency",r.getDealtCurrency());
        b.put("timeInForce","FOK"); b.put("valueDate",businessDate(2)); b.put("org","NEOFX"); b.put("account","NEOFX");
        ObjectNode c=mapper.createObjectNode(); c.put("CIF","1234553"); c.put("Channel","RBG-SWIFT"); c.put("Settlement","NOSTRO"); c.put("OBDXRef","XX12345"); c.put("OBPRef","xx12345"); c.put("Reversal","TRUE"); b.set("customParameters",c);
        HttpHeaders h=new HttpHeaders(); h.setContentType(MediaType.APPLICATION_JSON);
        return restTemplate.exchange(config.getBaseUrl()+config.getPlaceOrderPath(),HttpMethod.POST,new HttpEntity<>(b.toString(),h),PlaceOrderResponse.class);
    }
    public String valueDate(){return businessDate(2);}
    private String titleCase(String v){if(v==null||v.isBlank())return v;return Character.toUpperCase(v.charAt(0))+v.substring(1).toLowerCase();}
    private String businessDate(int days){LocalDate d=LocalDate.now();int n=0;while(n<days){d=d.plusDays(1);DayOfWeek w=d.getDayOfWeek();if(w!=DayOfWeek.SATURDAY&&w!=DayOfWeek.SUNDAY)n++;}return d.toString();}
}
