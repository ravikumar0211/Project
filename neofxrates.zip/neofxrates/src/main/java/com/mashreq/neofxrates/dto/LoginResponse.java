package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LoginResponse {

    private String status;

    private Long expiryTime;

    private Long serverUTCTime;

    public LoginResponse() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(Long expiryTime) {
        this.expiryTime = expiryTime;
    }

    public Long getServerUTCTime() {
        return serverUTCTime;
    }

    public void setServerUTCTime(Long serverUTCTime) {
        this.serverUTCTime = serverUTCTime;
    }

    @Override
    public String toString() {
        return "LoginResponse{" +
                "status='" + status + '\'' +
                ", expiryTime=" + expiryTime +
                ", serverUTCTime=" + serverUTCTime +
                '}';
    }
}