package com.mashreq.obms.neofxrates.dealbooking.service;

import com.mashreq.obms.neofxrates.dto.DealBookingRequest;
import com.mashreq.obms.neofxrates.msApi.FxIntegralAcceptQuoteApi;
import com.mashreq.obms.neofxrates.msApi.FxIntegralQueryQuoteApi;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;

class DealBookingServiceTest {
    @Test
    void acceptThenQueryInOrder() {
        FxIntegralAcceptQuoteApi accept = mock(FxIntegralAcceptQuoteApi.class);
        FxIntegralQueryQuoteApi query = mock(FxIntegralQueryQuoteApi.class);
        DealBookingResponseMapper mapper = mock(DealBookingResponseMapper.class);
        DealBookingService service = new DealBookingService(accept, query, mapper);
        DealBookingRequest request = request();
        when(accept.acceptQuote(eq("REQ1"), any())).thenReturn(ResponseEntity.ok("accepted"));
        when(query.queryQuote("REQ1")).thenReturn(ResponseEntity.ok("{\"event\":\"QUOTE\",\"transactionId\":\"TX1\"}"));
        service.acceptQuoteAndQuery(request);
        InOrder inOrder = inOrder(accept, query, mapper);
        inOrder.verify(accept).acceptQuote(eq("REQ1"), any());
        inOrder.verify(query).queryQuote("REQ1");
        inOrder.verify(mapper).map(eq("REQ1"), any(), eq("{\"event\":\"QUOTE\",\"transactionId\":\"TX1\"}"));
    }

    @Test
    void queryIsNotCalledWhenAcceptFails() {
        FxIntegralAcceptQuoteApi accept = mock(FxIntegralAcceptQuoteApi.class);
        FxIntegralQueryQuoteApi query = mock(FxIntegralQueryQuoteApi.class);
        DealBookingResponseMapper mapper = mock(DealBookingResponseMapper.class);
        DealBookingService service = new DealBookingService(accept, query, mapper);
        DealBookingRequest request = request();
        when(accept.acceptQuote(eq("REQ1"), any())).thenReturn(ResponseEntity.badRequest().body("failed"));
        try { service.acceptQuoteAndQuery(request); } catch (IllegalStateException ignored) { }
        verifyNoInteractions(query, mapper);
    }

    private DealBookingRequest request() {
        DealBookingRequest request = new DealBookingRequest();
        request.setRequestId("REQ1"); request.setQuoteId("Q1"); request.setSide("BUY"); request.setSymbol("EUR/USD"); request.setDealtCurrency("EUR"); request.setTransactionId("TX1"); request.setClOrderId("CL1"); request.setRfq(true);
        return request;
    }
}
