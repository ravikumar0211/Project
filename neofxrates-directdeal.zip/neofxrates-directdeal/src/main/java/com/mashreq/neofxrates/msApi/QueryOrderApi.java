package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.QueryOrderResponse;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class QueryOrderApi {
    private final ApplicationConfig config; private final RestTemplate restTemplate;
    public QueryOrderApi(ApplicationConfig config,RestTemplate restTemplate){this.config=config;this.restTemplate=restTemplate;}
    public ResponseEntity<QueryOrderResponse[]> queryOrder(String orderId){
        String path=config.getQueryOrderPath().replace("{orderId}",orderId);
        return restTemplate.exchange(config.getBaseUrl()+path,HttpMethod.GET,HttpEntity.EMPTY,QueryOrderResponse[].class);
    }
}
