package com.mashreq.neofxrates.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.external")
public class ExternalProperties {
    private String baseUrl;
    private String stripPathPrefix = "/v2";
    private long timeoutMs = 30000;

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getStripPathPrefix() { return stripPathPrefix; }
    public void setStripPathPrefix(String stripPathPrefix) { this.stripPathPrefix = stripPathPrefix; }
    public long getTimeoutMs() { return timeoutMs; }
    public void setTimeoutMs(long timeoutMs) { this.timeoutMs = timeoutMs; }
}
