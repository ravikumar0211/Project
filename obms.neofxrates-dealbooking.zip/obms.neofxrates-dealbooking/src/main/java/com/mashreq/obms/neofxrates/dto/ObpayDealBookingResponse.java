package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class ObpayDealBookingResponse {
    private final String status;
    private final String message;
    private final String requestId;
    private final String transactionId;
    private final String quoteId;
    private final String clOrderId;
    private final String side;
    private final String symbol;
    private final String dealtCurrency;
    private final boolean accepted;
    private final JsonNode acceptedData;
}
