# NeoFX Deal Booking

Spring Boot service for the Deal Booking flow with only two downstream operations:

1. **Accept Quote** — `POST /v2/rfs/{requestId}`
2. **Query Quote** — `GET /v2/rfs/{requestId}`

Swagger/OpenAPI UI is **not included**.

## MS APIs

### Accept Quote
`POST /api/dealbooking/acceptQuote/{requestId}`

Request body:
```json
{
  "quoteId": "G-6055299-1a08052299b-NEOFX-c8dc252",
  "side": "Buy",
  "symbol": "EUR/USD",
  "dealtCurrency": "EUR",
  "transactionId": "FXI3522946779",
  "clOrderId": "RFQ_AEDEUR0001",
  "rfq": "true",
  "cif": "1234553",
  "refNo": "REF9921102",
  "source": "OBPAY"
}
```

The MS forwards only the fields required by the downstream Postman Accept Quote request: `quoteId`, `side`, `symbol`, `dealtCurrency`, `transactionId`, `clOrderId`, and `rfq`.

### Query Quote
`GET /api/dealbooking/queryQuote/{requestId}`

The MS calls downstream:
`GET /v2/rfs/{requestId}`

The response is mapped to the supplied Trade Confirmation response contract.

## Configuration

Set the HMAC credentials through environment variables:
- `HMAC_USERNAME`
- `HMAC_SECRET`
- `HMAC_SECRET_ENCODING`
- `HMAC_HEADERS`
- `FX_INTEGRAL_BASE_URL`

Default UAT base URL is `https://uat.fxinside.net`.
