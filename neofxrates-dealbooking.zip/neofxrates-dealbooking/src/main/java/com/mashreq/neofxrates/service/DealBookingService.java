package com.mashreq.neofxrates.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.neofxrates.dto.DealBookingRequest;
import com.mashreq.neofxrates.dto.DealBookingResponse;
import com.mashreq.neofxrates.msApi.AcceptQuoteApi;
import com.mashreq.neofxrates.msApi.QueryQuoteApi;
import org.springframework.stereotype.Service;

@Service
public class DealBookingService {

    private final AcceptQuoteApi acceptQuoteApi;
    private final QueryQuoteApi queryQuoteApi;
    private final ObjectMapper objectMapper;

    public DealBookingService(AcceptQuoteApi acceptQuoteApi,
                              QueryQuoteApi queryQuoteApi,
                              ObjectMapper objectMapper) {
        this.acceptQuoteApi = acceptQuoteApi;
        this.queryQuoteApi = queryQuoteApi;
        this.objectMapper = objectMapper;
    }

    public JsonNode acceptQuote(DealBookingRequest request) {
        String response = acceptQuoteApi.accept(toAcceptRequest(request));
        return readJson(response);
    }

    public JsonNode queryQuote(String requestId) {
        return readJson(queryQuoteApi.query(requestId));
    }

    public DealBookingResponse execute(DealBookingRequest request) {
        // No retry and no cached-rate fallback: if Accept Quote fails,
        // Query Quote is not called and the error is returned immediately.
        JsonNode acceptResponse = acceptQuote(request);
        JsonNode queryResponse = queryQuote(request.getRequestId());

        return new DealBookingResponse(
                "DEAL_BOOKING",
                request.getRequestId(),
                request.getQuoteId(),
                acceptResponse,
                queryResponse
        );
    }

    private AcceptQuoteRequest toAcceptRequest(DealBookingRequest request) {
        return new AcceptQuoteRequest(
                request.getRequestId(),
                request.getQuoteId(),
                request.getSide(),
                request.getSymbol(),
                request.getDealtCurrency(),
                request.getTransactionId(),
                request.getClOrderId(),
                request.getRfq(),
                request.getCif(),
                request.getRefNo(),
                request.getSource()
        );
    }

    private JsonNode readJson(String response) {
        try {
            return objectMapper.readTree(response == null || response.isBlank() ? "{}" : response);
        } catch (Exception e) {
            throw new IllegalStateException("External API returned a non-JSON response: " + response, e);
        }
    }
}
