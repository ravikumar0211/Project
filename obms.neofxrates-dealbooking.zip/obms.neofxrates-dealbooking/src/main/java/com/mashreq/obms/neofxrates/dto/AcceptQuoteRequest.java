package com.mashreq.obms.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AcceptQuoteRequest {
    private String quoteId;
    private String side;
    private String symbol;
    private String dealtCurrency;
    private String transactionId;
    private String clOrderId;
    @JsonProperty("rfq")
    private Boolean rfq;
}
