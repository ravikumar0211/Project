package com.mashreq.neofxrates.controller;

import com.mashreq.neofxrates.dto.DirectDealFlowRequest;
import com.mashreq.neofxrates.dto.DirectDealResponse;
import com.mashreq.neofxrates.service.DirectDealService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/directdeal")
@RequiredArgsConstructor
public class DirectDealController {

    private final DirectDealService directDealService;

    @PostMapping("/execute")
    public ResponseEntity<DirectDealResponse> directDeal(
            @Valid @RequestBody DirectDealFlowRequest request) {
        return directDealService.execute(request);
    }
}
