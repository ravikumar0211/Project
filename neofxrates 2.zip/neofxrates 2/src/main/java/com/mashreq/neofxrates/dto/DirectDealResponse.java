package com.mashreq.neofxrates.dto;

import lombok.Data;

@Data
public class DirectDealResponse {
    private String status;
    private String message;
    private String orderId;
    private String orderStatus;
    private BookTradeResponse bookTrade;
}
