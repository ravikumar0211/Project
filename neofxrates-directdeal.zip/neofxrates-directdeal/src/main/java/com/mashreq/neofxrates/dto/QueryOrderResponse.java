package com.mashreq.neofxrates.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.util.List;
@JsonIgnoreProperties(ignoreUnknown=true)
public class QueryOrderResponse {
    private String orderId; private String coId; private String status; private String symbol; private String side;
    private BigDecimal size; private BigDecimal cumQty; private BigDecimal averagePrice; private String tradeDate; private List<Object> fills;
    public String getOrderId(){return orderId;} public void setOrderId(String v){orderId=v;}
    public String getCoId(){return coId;} public void setCoId(String v){coId=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getSymbol(){return symbol;} public void setSymbol(String v){symbol=v;}
    public String getSide(){return side;} public void setSide(String v){side=v;}
    public BigDecimal getSize(){return size;} public void setSize(BigDecimal v){size=v;}
    public BigDecimal getCumQty(){return cumQty;} public void setCumQty(BigDecimal v){cumQty=v;}
    public BigDecimal getAveragePrice(){return averagePrice;} public void setAveragePrice(BigDecimal v){averagePrice=v;}
    public String getTradeDate(){return tradeDate;} public void setTradeDate(String v){tradeDate=v;}
    public List<Object> getFills(){return fills;} public void setFills(List<Object> v){fills=v;}
}
