# OBPAY Deal Booking Flow

This project contains ONLY the Post Trade STP Deal Booking flow requested from the supplied Postman collection: Accept Quote followed by Query Quote.

```text
OBPAY
  |
  | POST /dealbooking/acceptQuote
  v
DealBookingController
  |
  v
DealBookingService
  |
  +-- 1. Accept Quote
  |      POST /v2/rfs/{requestId}
  |
  +-- 2. Query Quote
         GET /v2/rfs/{requestId}
               |
               v
      DealBookingResponseMapper
               |
               v
      ObpayDealBookingResponse
               |
               v
             OBPAY
```

## Integral calls

### 1. Accept Quote
`POST {baseUrl}/v2/rfs/{requestId}`

Body is exactly the Accept Quote body from the supplied Postman collection:

```json
{
  "quoteId": "{{quoteId}}",
  "side": "{{side}}",
  "symbol": "{{symbol}}",
  "dealtCurrency": "{{dealtCurrency}}",
  "transactionId": "{{transactionId}}",
  "clOrderId": "{{clOrderId}}",
  "rfq": "{{rfq}}"
}
```

### 2. Query Quote
`GET {baseUrl}/v2/rfs/{requestId}`

The same `requestId` is used. Query Quote is called only after Accept Quote returns a 2xx response.

## Explicitly excluded

- Request Quote
- Login/SSO
- Indicative FX enquiry
- Post Trade STP messages polling
- Database/JPA/repositories
- Any workflow not represented by Accept Quote -> Query Quote

## HMAC

Outbound Accept Quote and Query Quote calls use the HMAC pattern from the supplied Postman collection: `date request-line digest`, raw Base64 SHA-256 body digest, `/v2` removed from the signed request path, and `hmac username="...", algorithm="hmac-sha256"...` Authorization.
