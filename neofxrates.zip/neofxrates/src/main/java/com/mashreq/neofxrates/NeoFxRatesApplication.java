package com.mashreq.neofxrates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeoFxRatesApplication {
    public static void main(String[] args) {
        SpringApplication.run(NeoFxRatesApplication.class, args);
    }
}
