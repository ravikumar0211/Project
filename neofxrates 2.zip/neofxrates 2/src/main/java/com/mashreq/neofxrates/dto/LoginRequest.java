package com.mashreq.neofxrates.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoginRequest {
    @NotBlank private String user;
    @NotBlank private String pass;
    @NotBlank private String org;

}
