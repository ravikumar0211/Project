package com.mashreq.neofxrates.repository;

import com.mashreq.neofxrates.entity.DealBookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DealBookingRepository extends JpaRepository<DealBookingEntity, Long> {
    Optional<DealBookingEntity> findByRequestId(String requestId);
}
