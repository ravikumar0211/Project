package com.mashreq.neofxrates.service;

import com.mashreq.neofxrates.dto.BookTradeResponse;
import com.mashreq.neofxrates.dto.DirectDealFlowRequest;
import com.mashreq.neofxrates.dto.DirectDealRequest;
import com.mashreq.neofxrates.dto.DirectDealResponse;
import com.mashreq.neofxrates.dto.LoginResponse;
import com.mashreq.neofxrates.dto.PlaceOrderResponse;
import com.mashreq.neofxrates.dto.QueryOrderResponse;
import com.mashreq.neofxrates.exception.ApiException;
import com.mashreq.neofxrates.msApi.BookTradeApi;
import com.mashreq.neofxrates.msApi.LoginApi;
import com.mashreq.neofxrates.msApi.PlaceOrderApi;
import com.mashreq.neofxrates.msApi.QueryOrderApi;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
public class DirectDealService {

    private final LoginApi loginApi;
    private final PlaceOrderApi placeOrderApi;
    private final QueryOrderApi queryOrderApi;
    private final BookTradeApi bookTradeApi;

    public ResponseEntity<DirectDealResponse> execute(
            DirectDealFlowRequest flow) {

        validate(flow);

        // 1. LOGIN
        // Login is HMAC signed.
        // No SSO token is used.
        call("LOGIN", () -> {

            ResponseEntity<LoginResponse> response =
                    loginApi.login(flow.getLogin());

            require2xx("LOGIN", response);

            if (response.getBody() == null) {
                throw new ApiException(
                        "LOGIN",
                        HttpStatus.BAD_GATEWAY,
                        "Login response is empty");
            }

            return response.getBody();
        });

        DirectDealRequest request = flow.getDirectDeal();

        String clientOrderId =
                "DIRECT_" + System.currentTimeMillis();

        // 2. PLACE ORDER
        PlaceOrderResponse placed = call(
                "PLACE_ORDER",
                () -> {

                    ResponseEntity<PlaceOrderResponse> response =
                            placeOrderApi.placeOrder(
                                    request,
                                    clientOrderId);

                    require2xx("PLACE_ORDER", response);

                    if (response.getBody() == null
                            || response.getBody().getOrderId() == null
                            || response.getBody().getOrderId().isBlank()) {

                        throw new ApiException(
                                "PLACE_ORDER",
                                HttpStatus.BAD_GATEWAY,
                                "Place Order response does not contain orderId");
                    }

                    return response.getBody();
                });

        String orderId = placed.getOrderId();

        // 3. QUERY ORDER
        QueryOrderResponse order = call(
                "QUERY_ORDER",
                () -> {

                    ResponseEntity<QueryOrderResponse[]> response =
                            queryOrderApi.queryOrder(orderId);

                    require2xx("QUERY_ORDER", response);

                    QueryOrderResponse[] orders =
                            response.getBody();

                    if (orders == null
                            || orders.length == 0
                            || orders[0] == null) {

                        throw new ApiException(
                                "QUERY_ORDER",
                                HttpStatus.BAD_GATEWAY,
                                "Query Order returned no order for orderId="
                                        + orderId);
                    }

                    return orders[0];
                });

        // Order must be FILLED before Book Trade.
        if (!"FILLED".equalsIgnoreCase(order.getStatus())) {

            throw new ApiException(
                    "QUERY_ORDER",
                    HttpStatus.BAD_GATEWAY,
                    "Order is not FILLED. Current status="
                            + order.getStatus()
                            + ". Book Trade was not called.");
        }

        if (order.getAveragePrice() == null) {

            throw new ApiException(
                    "QUERY_ORDER",
                    HttpStatus.BAD_GATEWAY,
                    "Query Order response does not contain averagePrice");
        }

        // 4. BOOK TRADE
        // Fill rate comes from Query Order.
        BookTradeResponse booked = call(
                "BOOK_TRADE",
                () -> {

                    ResponseEntity<BookTradeResponse> response =
                            bookTradeApi.bookTrade(
                                    request,
                                    clientOrderId,
                                    order.getAveragePrice().toPlainString(),
                                    placeOrderApi.valueDate(request));

                    require2xx("BOOK_TRADE", response);

                    if (response.getBody() == null) {

                        throw new ApiException(
                                "BOOK_TRADE",
                                HttpStatus.BAD_GATEWAY,
                                "Book Trade response is empty");
                    }

                    return response.getBody();
                });

        // Final response
        DirectDealResponse result =
                new DirectDealResponse();

        result.setStatus("SUCCESS");
        result.setMessage(
                "Direct Deal booked successfully");
        result.setOrderId(orderId);
        result.setOrderStatus(order.getStatus());
        result.setBookTrade(booked);

        return ResponseEntity.ok(result);
    }

    private void validate(
            DirectDealFlowRequest flow) {

        if (flow == null
                || flow.getLogin() == null
                || flow.getDirectDeal() == null) {

            throw new ApiException(
                    "VALIDATION",
                    HttpStatus.BAD_REQUEST,
                    "login and directDeal are required");
        }
    }

    private void require2xx(
            String step,
            ResponseEntity<?> response) {

        if (response == null) {

            throw new ApiException(
                    step,
                    HttpStatus.BAD_GATEWAY,
                    "Integral returned no response");
        }

        if (!response.getStatusCode().is2xxSuccessful()) {

            /*
             * Spring Boot 3:
             * getStatusCode() returns HttpStatusCode.
             *
             * ApiException expects HttpStatus.
             * Convert using HttpStatus.resolve().
             */
            HttpStatus status =
                    HttpStatus.resolve(
                            response.getStatusCode().value());

            if (status == null) {
                status = HttpStatus.BAD_GATEWAY;
            }

            throw new ApiException(
                    step,
                    status,
                    "Integral returned HTTP "
                            + response.getStatusCode().value());
        }
    }

    private <T> T call(
            String step,
            Supplier<T> action) {

        try {

            return action.get();

        } catch (ApiException ex) {

            throw ex;

        } catch (RestClientResponseException ex) {

            /*
             * Spring Boot 3 returns HttpStatusCode here.
             * Convert it to HttpStatus before passing it
             * to ApiException.
             */
            HttpStatus status =
                    HttpStatus.resolve(
                            ex.getStatusCode().value());

            if (status == null) {
                status = HttpStatus.BAD_GATEWAY;
            }

            throw new ApiException(
                    step,
                    status,
                    "Integral API returned HTTP "
                            + ex.getStatusCode().value(),
                    ex);

        } catch (Exception ex) {

            throw new ApiException(
                    step,
                    HttpStatus.BAD_GATEWAY,
                    "Unable to call Integral API: "
                            + ex.getMessage(),
                    ex);
        }
    }
}