package com.mashreq.obms.neofxrates.dealbooking.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.obms.neofxrates.dto.ObpayDealBookingResponse;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DealBookingResponseMapperTest {
    private final DealBookingResponseMapper mapper = new DealBookingResponseMapper(new ObjectMapper());

    @Test void mapsBuyOfferQuote() {
        AcceptQuoteRequest request = new AcceptQuoteRequest(); request.setQuoteId("Q-IN"); request.setSide("BUY"); request.setTransactionId("TX-IN"); request.setClOrderId("CL1"); request.setSymbol("EUR/USD"); request.setDealtCurrency("EUR");
        String query = "{\"event\":\"QUOTE\",\"transactionId\":\"TX1\",\"quotes\":[{\"offers\":[{\"type\":\"OFFER\",\"quoteId\":\"Q1\"}]}]}";
        ObpayDealBookingResponse response = mapper.map("REQ1", request, query);
        assertEquals("SUCCESS", response.getStatus()); assertEquals("TX1", response.getTransactionId()); assertEquals("Q1", response.getQuoteId()); assertEquals("REQ1", response.getRequestId());
    }

    @Test void mapsSellBidQuote() {
        AcceptQuoteRequest request = new AcceptQuoteRequest(); request.setQuoteId("Q-IN"); request.setSide("SELL");
        String query = "{\"event\":\"QUOTE\",\"quotes\":[{\"bids\":[{\"type\":\"BID\",\"quoteId\":\"Q2\"}]}]}";
        ObpayDealBookingResponse response = mapper.map("REQ2", request, query);
        assertEquals("Q2", response.getQuoteId());
    }
}
