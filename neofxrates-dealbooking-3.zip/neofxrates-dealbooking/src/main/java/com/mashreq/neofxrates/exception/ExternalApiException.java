package com.mashreq.neofxrates.exception;

public class ExternalApiException extends RuntimeException {
    private final int status;
    private final String responseBody;

    public ExternalApiException(int status, String responseBody) {
        super("External FX Integral API returned HTTP " + status);
        this.status = status;
        this.responseBody = responseBody;
    }

    public int getStatus() { return status; }
    public String getResponseBody() { return responseBody; }
}
