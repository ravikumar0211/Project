# HMAC setup

The downstream FX API calls use the same HMAC signing method as the supplied reference `obms-neofxrates-api` project.

Configure:

```text
INTEGRAL_HMAC_USERNAME=NEOFXAPI@NEOFX
INTEGRAL_HMAC_SECRET=<your HMAC secret>
INTEGRAL_HMAC_SECRET_ENCODING=utf8
INTEGRAL_HMAC_STRIP_PATH_PREFIX=/v2
INTEGRAL_HMAC_HEADERS=date request-line digest
INTEGRAL_HMAC_BODY_LINE_ENDING=lf
```

The interceptor signs all four calls:

```text
POST /v2/sso/login
POST /v2/orders
GET  /v2/orders/{orderId}
POST /v2/trades
```

The `/v2` prefix is removed only inside the HMAC request-line, matching the supplied reference implementation.

No SSO token is generated, persisted, or sent by this application.
