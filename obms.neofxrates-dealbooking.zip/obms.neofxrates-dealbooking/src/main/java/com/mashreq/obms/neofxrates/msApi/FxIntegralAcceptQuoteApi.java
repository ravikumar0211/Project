package com.mashreq.obms.neofxrates.msApi;

import com.mashreq.obms.neofxrates.config.ApplicationConfig;
import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class FxIntegralAcceptQuoteApi {
    private final ApplicationConfig applicationConfig;
    private final RestTemplate restTemplate;

    public ResponseEntity<String> acceptQuote(String requestId, AcceptQuoteRequest request) {
        String url = applicationConfig.getBaseUrl() + "/v2/rfs/" + requestId;
        return restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(request), String.class);
    }
}
