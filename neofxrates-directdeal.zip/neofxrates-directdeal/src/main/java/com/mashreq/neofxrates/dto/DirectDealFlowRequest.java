package com.mashreq.neofxrates.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

public class DirectDealFlowRequest {
    @NotNull @Valid private LoginRequest login;
    @NotNull @Valid private DirectDealRequest directDeal;
    public LoginRequest getLogin(){return login;} public void setLogin(LoginRequest v){login=v;}
    public DirectDealRequest getDirectDeal(){return directDeal;} public void setDirectDeal(DirectDealRequest v){directDeal=v;}
}
