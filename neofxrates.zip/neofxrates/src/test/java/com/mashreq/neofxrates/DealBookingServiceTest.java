package com.mashreq.neofxrates;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.*;
import com.mashreq.neofxrates.msApi.AcceptQuoteApi;
import com.mashreq.neofxrates.msApi.LoginApi;
import com.mashreq.neofxrates.msApi.QueryQuoteApi;
import com.mashreq.neofxrates.repository.DealBookingRepository;
import com.mashreq.neofxrates.service.DealBookingService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;

class DealBookingServiceTest {
    @Test
    void getcalledExecutesLoginAcceptThenQueryUsingReturnedRequestId() {
        LoginApi loginApi = Mockito.mock(LoginApi.class);
        AcceptQuoteApi acceptApi = Mockito.mock(AcceptQuoteApi.class);
        QueryQuoteApi queryApi = Mockito.mock(QueryQuoteApi.class);
        DealBookingRepository repository = Mockito.mock(DealBookingRepository.class);
        ApplicationConfig config = new ApplicationConfig(); config.setQueryAttempts(1); config.setQueryDelayMs(0);
        DealBookingService service = new DealBookingService(loginApi, acceptApi, queryApi, repository, new ObjectMapper(), config);

        LoginRequest login = new LoginRequest(); login.setUser("prov"); login.setPass("Forex1234$"); login.setOrg("NEOFX");
        LoginResponse loginResponse = new LoginResponse(); loginResponse.setStatus("SUCCESS");
        Mockito.when(loginApi.login(any())).thenReturn(new LoginApi.LoginResult(loginResponse, "TOKEN"));

        AcceptQuoteRequest accept = new AcceptQuoteRequest();
        accept.setClOrderId("RFQ_TEST_1"); accept.setSymbol("EUR/USD"); accept.setAmount(BigDecimal.valueOf(1000));
        accept.setDealtCurrency("EUR"); accept.setSide("BUY"); accept.setRfq(true); accept.setExpiry(120L);
        accept.setPriceType("Spot"); accept.setCustomerAccount("RBG_NEO_GOLD"); accept.setCustomerOrg("RBG_NEO_GOLD");
        accept.setNearValueDate("SPOT"); accept.setCustomParameters(Map.of("CIF", "1234"));

        DealBookingFlowRequest request = new DealBookingFlowRequest(); request.setLogin(login); request.setAcceptQuote(accept);
        AcceptQuoteResponse accepted = new AcceptQuoteResponse(); accepted.setClOrderId("RFQ_TEST_1"); accepted.setRequestId("REQ-123"); accepted.setEvent("REQUEST_RECEIVED");
        Mockito.when(acceptApi.acceptQuote(eq(accept), anyString(), eq("TOKEN"))).thenReturn(ResponseEntity.accepted().body(accepted));

        QueryQuoteResponse query = new QueryQuoteResponse(); query.setRequestId("REQ-123"); query.setEvent("QUOTE");
        QueryQuoteResponse.Quote q = new QueryQuoteResponse.Quote(); q.setSymbol("EUR/USD");
        QueryQuoteResponse.Offer offer = new QueryQuoteResponse.Offer(); offer.setQuoteId("Q-1"); offer.setRate(BigDecimal.valueOf(1.18));
        q.setOffers(List.of(offer)); query.setQuotes(List.of(q));
        Mockito.when(queryApi.queryQuote(eq("REQ-123"), anyString(), eq("TOKEN"))).thenReturn(ResponseEntity.ok(query));

        var result = service.getcalled(request);
        assertEquals("COMPLETED", result.getBody().getFlowStatus());
        assertEquals("REQ-123", result.getBody().getAcceptQuote().getRequestId());
        assertEquals("QUOTE", result.getBody().getQueryQuote().getEvent());
        Mockito.verify(loginApi).login(eq(login));
        Mockito.verify(acceptApi).acceptQuote(eq(accept), anyString(), eq("TOKEN"));
        Mockito.verify(queryApi).queryQuote(eq("REQ-123"), anyString(), eq("TOKEN"));
    }
}
