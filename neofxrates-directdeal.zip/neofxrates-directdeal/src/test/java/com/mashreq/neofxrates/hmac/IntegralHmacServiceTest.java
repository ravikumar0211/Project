package com.mashreq.neofxrates.hmac;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import static org.junit.jupiter.api.Assertions.*;
class IntegralHmacServiceTest {
 @Test void signsLoginLikeColleagueProject(){
  IntegralHmacProperties p=new IntegralHmacProperties();
  p.setEnabled(true); p.setUsername("NEOFXAPI@NEOFX"); p.setSecret("test-secret");
  HmacResponse r=new IntegralHmacService(p).generateHmacHeaders(HttpMethod.POST,"https://uat.fxinside.net/v2/sso/login","{\"user\":\"prov\"}","application/json");
  assertEquals("POST /sso/login HTTP/1.1",r.getRequestLine());
  assertEquals("hmac",r.getType());
  assertTrue(r.getAuthorization().startsWith("hmac username=\"NEOFXAPI@NEOFX\""));
 }
}
