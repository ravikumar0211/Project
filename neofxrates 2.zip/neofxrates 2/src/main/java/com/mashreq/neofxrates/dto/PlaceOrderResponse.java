package com.mashreq.neofxrates.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown=true)
public class PlaceOrderResponse {
    private String orderId;
    private String coId;
    private String status;
    private String symbol;
    private String side;
    private BigDecimal size;

}
