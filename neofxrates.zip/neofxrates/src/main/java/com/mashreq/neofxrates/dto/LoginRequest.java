package com.mashreq.neofxrates.dto;

import jakarta.validation.constraints.NotBlank;

public class LoginRequest {
    @NotBlank private String user;
    @NotBlank private String pass;
    @NotBlank private String org;
    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
    public String getPass() { return pass; }
    public void setPass(String pass) { this.pass = pass; }
    public String getOrg() { return org; }
    public void setOrg(String org) { this.org = org; }
}
