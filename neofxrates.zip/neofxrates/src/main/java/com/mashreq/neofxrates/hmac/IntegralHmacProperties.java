package com.mashreq.neofxrates.hmac;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.hmac")
public class IntegralHmacProperties {
    private boolean enabled = true;
    private String username = "";
    private String secret = "";
    private String secretEncoding = "utf8";
    private String stripPathPrefix = "/v2";
    private String headers = "date request-line digest";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getSecret() { return secret; }
    public void setSecret(String secret) { this.secret = secret; }
    public String getSecretEncoding() { return secretEncoding; }
    public void setSecretEncoding(String secretEncoding) { this.secretEncoding = secretEncoding; }
    public String getStripPathPrefix() { return stripPathPrefix; }
    public void setStripPathPrefix(String stripPathPrefix) { this.stripPathPrefix = stripPathPrefix; }
    public String getHeaders() { return headers; }
    public void setHeaders(String headers) { this.headers = headers; }
}
