# NEOFX MVP1 - Deal Booking

Package: `com.mashreq.neofxrates`

Java: **17 LTS**

Spring Boot: **3.5.6**

## Controller design

There is intentionally **one controller API** for the business workflow:

`POST /api/v1/dealbooking`

The controller calls only:

`dealBookingService.getcalled(request)`

The service internally executes:

1. Login -> `POST /v2/sso/login`
2. Accept Quote -> `POST /v2/rfsRequest`
3. Read `requestId` from Accept Quote response
4. Query Quote -> `GET /v2/rfs/{requestId}`
5. Query repeats until a `QUOTE` with offers/bids is returned or configured attempts are exhausted.

The supplied diagram is reflected in this sequence. The supplied Postman Dealing Workflow RFQ/Query examples are used for the RFQ payload style and Query Quote response model; the Deal Booking Accept Quote endpoint remains `/v2/rfsRequest` from the earlier Deal Booking workflow.

## Configuration

Set the HMAC values in environment variables or `application.properties`. Never commit real secrets.

## Run

```bash
mvn clean test
mvn spring-boot:run
```

Swagger: `http://localhost:8080/swagger-ui.html`

H2 console: `http://localhost:8080/h2-console`

JDBC URL: `jdbc:h2:mem:neofxrates`

## Postman

Import `postman/NEOFX-MVP1-DealBooking.postman_collection.json`.

Only one local business endpoint is exposed by the controller. The Postman request sends Login and Accept Quote data together; the application performs the downstream calls internally.
