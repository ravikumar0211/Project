package com.mashreq.neofxrates.hmac;

import com.mashreq.neofxrates.config.ExternalProperties;
import com.mashreq.neofxrates.config.HmacProperties;
import com.mashreq.neofxrates.exception.ExternalApiException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.net.URI;
import java.time.Duration;
import java.util.Locale;

@Component
public class HmacExternalClient {

    private final RestClient restClient;
    private final HmacSigner signer;
    private final HmacProperties hmacProperties;
    private final ExternalProperties externalProperties;

    public HmacExternalClient(HmacSigner signer,
                              HmacProperties hmacProperties,
                              ExternalProperties externalProperties) {
        this.signer = signer;
        this.hmacProperties = hmacProperties;
        this.externalProperties = externalProperties;
        this.restClient = RestClient.builder()
                .baseUrl(externalProperties.getBaseUrl())
                .build();
    }

    public String post(String path, String body) {
        String date = signer.utcDate();
        String digest = signer.digest(body);
        String pathForSigning = normalizeForSigning(path);
        String signingString = buildSigningString("POST", pathForSigning, date, digest);
        String signature = signer.sign(signingString);

        return execute(
                restClient.post()
                        .uri(path)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(HttpHeaders.DATE, date)
                        .header("Digest", digest)
                        .header("type", "hmac")
                        .header(HttpHeaders.AUTHORIZATION, signer.authorization(signature))
                        .body(body)
        );
    }

    public String get(String path) {
        String body = "";
        String date = signer.utcDate();
        String digest = signer.digest(body);
        String pathForSigning = normalizeForSigning(path);
        String signingString = buildSigningString("GET", pathForSigning, date, digest);
        String signature = signer.sign(signingString);

        return execute(
                restClient.get()
                        .uri(path)
                        .header(HttpHeaders.DATE, date)
                        .header("Digest", digest)
                        .header("type", "hmac")
                        .header(HttpHeaders.AUTHORIZATION, signer.authorization(signature))
        );
    }

    private String execute(RestClient.RequestHeadersSpec<?> request) {
        return request.exchange((clientRequest, clientResponse) -> {
            String response = clientResponse.getBody() == null
                    ? ""
                    : new String(clientResponse.getBody().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);

            if (clientResponse.getStatusCode().isError()) {
                throw new ExternalApiException(clientResponse.getStatusCode().value(), response);
            }
            return response;
        });
    }

    private String normalizeForSigning(String path) {
        String result = path;
        String prefix = externalProperties.getStripPathPrefix();
        if (prefix != null && !prefix.isBlank()
                && result.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))) {
            result = result.substring(prefix.length());
        }
        return result.startsWith("/") ? result : "/" + result;
    }

    private String buildSigningString(String method, String path, String date, String digest) {
        String headers = hmacProperties.getHeaders().toLowerCase(Locale.ROOT)
                .trim().replaceAll("\\s+", " ");

        return java.util.Arrays.stream(headers.split(" "))
                .map(h -> switch (h) {
                    case "date" -> "date: " + date;
                    case "digest" -> "digest: " + digest;
                    case "request-line" -> method + " " + path + " HTTP/1.1";
                    default -> h + ": ";
                })
                .collect(java.util.stream.Collectors.joining("\n"));
    }
}
