package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.hmac.HmacExternalClient;
import org.springframework.stereotype.Component;

@Component
public class QueryQuoteApi {
    private final HmacExternalClient client;

    public QueryQuoteApi(HmacExternalClient client) {
        this.client = client;
    }

    /** Matches Postman Step 4: GET /v2/rfs/{requestId}. */
    public String query(String requestId) {
        return client.get("/v2/rfs/" + requestId);
    }
}
