package com.mashreq.obms.neofxrates.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.obms.neofxrates.dto.AcceptQuoteRequest;
import com.mashreq.obms.neofxrates.dto.ObpayDealBookingResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DealBookingResponseMapper {
    private final ObjectMapper objectMapper;

    public ObpayDealBookingResponse map(String requestId, AcceptQuoteRequest request, String queryResponse) {
        try {
            JsonNode data = objectMapper.readTree(queryResponse);
            String transactionId = text(data, "transactionId", request.getTransactionId());
            String quoteId = findAcceptedQuoteId(data, request.getSide(), request.getQuoteId());
            return ObpayDealBookingResponse.builder()
                    .status("SUCCESS")
                    .message("Deal booking accepted successfully")
                    .requestId(requestId)
                    .transactionId(transactionId)
                    .quoteId(quoteId)
                    .clOrderId(request.getClOrderId())
                    .side(request.getSide())
                    .symbol(request.getSymbol())
                    .dealtCurrency(request.getDealtCurrency())
                    .accepted(true)
                    .acceptedData(data)
                    .build();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to map Integral Query Quote response", e);
        }
    }

    private String findAcceptedQuoteId(JsonNode root, String side, String fallback) {
        JsonNode quotes = root.path("quotes");
        if (quotes.isArray() && !quotes.isEmpty()) {
            JsonNode quote = quotes.get(0);
            String collection = "SELL".equalsIgnoreCase(side) ? "bids" : "offers";
            String type = "SELL".equalsIgnoreCase(side) ? "BID" : "OFFER";
            JsonNode entries = quote.path(collection);
            if (entries.isArray()) {
                for (JsonNode entry : entries) {
                    if (type.equalsIgnoreCase(text(entry, "type", ""))) {
                        String id = text(entry, "quoteId", null);
                        if (id != null) return id;
                    }
                }
            }
        }
        return fallback;
    }

    private String text(JsonNode node, String field, String fallback) {
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? fallback : value.asText(fallback);
    }
}
