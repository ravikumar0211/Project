package com.mashreq.neofxrates.msApi;

import com.mashreq.neofxrates.config.ApplicationConfig;
import com.mashreq.neofxrates.dto.QueryQuoteResponse;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class QueryQuoteApi {
    private final ApplicationConfig config;
    private final RestTemplate restTemplate;
    public QueryQuoteApi(ApplicationConfig config, RestTemplate restTemplate) { this.config = config; this.restTemplate = restTemplate; }
    public ResponseEntity<QueryQuoteResponse> queryQuote(String requestId, String correlationId, String ssoToken) {
        String url = config.getBaseUrl() + config.getQueryQuotePath() + "/" + requestId;
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));
        if (correlationId != null) headers.set("X-Correlation-ID", correlationId);
        if (ssoToken != null && !ssoToken.isBlank()) headers.set("SSO_TOKEN", ssoToken);
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), QueryQuoteResponse.class);
    }
}
