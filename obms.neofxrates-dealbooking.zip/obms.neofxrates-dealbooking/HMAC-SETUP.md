# HMAC configuration

Set these environment variables:

- `INTEGRAL_BASE_URL`
- `INTEGRAL_HMAC_USERNAME`
- `INTEGRAL_HMAC_SECRET`
- optional `INTEGRAL_HMAC_SECRET_ENCODING` (`utf8` by default)

HMAC is applied only to outbound Integral calls in this project.
