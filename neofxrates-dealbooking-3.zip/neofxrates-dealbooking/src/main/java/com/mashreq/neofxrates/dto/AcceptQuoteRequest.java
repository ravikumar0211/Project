package com.mashreq.neofxrates.dto;

/** Exact downstream Accept Quote payload required by Postman collection. */
public record AcceptQuoteRequest(
        String requestId,
        String quoteId,
        String side,
        String symbol,
        String dealtCurrency,
        String transactionId,
        String clOrderId,
        String rfq
) {}
