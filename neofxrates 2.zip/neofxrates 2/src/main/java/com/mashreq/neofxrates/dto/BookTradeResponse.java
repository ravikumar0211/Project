package com.mashreq.neofxrates.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookTradeResponse {
    private String tradeId;
    private String createdTime;
    private String clientRequestId;
    private String status;
    private String message;
}
