package com.mashreq.neofxrates.exception;

import org.springframework.http.HttpStatus;

public class ApiException extends RuntimeException {
    private final HttpStatus status;
    private final String step;
    public ApiException(String step, HttpStatus status, String message) { super(message); this.step = step; this.status = status; }
    public ApiException(String step, HttpStatus status, String message, Throwable cause) { super(message, cause); this.step = step; this.status = status; }
    public HttpStatus getStatus() { return status; }
    public String getStep() { return step; }
}
