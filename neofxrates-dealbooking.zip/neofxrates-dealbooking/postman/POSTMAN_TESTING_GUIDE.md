# Postman Testing Guide

## 1. Set UAT URL

For direct FX Integral testing:

`baseUrl = https://uat.fxinside.net`

The exact endpoints are:

`POST {{baseUrl}}/v2/rfs/{{requestId}}`

`GET {{baseUrl}}/v2/rfs/{{requestId}}`

## 2. Required variables

Set these in a Postman Environment:

| Variable | Example |
|---|---|
| baseUrl | https://uat.fxinside.net |
| requestId | actual requestId from the quote flow |
| quoteId | actual quoteId |
| side | BUY |
| symbol | EUR/USD |
| dealtCurrency | EUR |
| transactionId | actual transactionId |
| clOrderId | RFQ_AEDEUR0001 |
| rfq | true |
| hmacUserId | your HMAC username |
| hmacSecret | your HMAC secret |
| hmacHeaders | date request-line digest |
| hmacStripPathPrefix | /v2 |

Do not paste real HMAC secrets into an exported collection.

## 3. Test Accept Quote

Method: POST

URL:

`{{baseUrl}}/v2/rfs/{{requestId}}`

Body:

```json
{
  "quoteId": "{{quoteId}}",
  "side": "{{side}}",
  "symbol": "{{symbol}}",
  "dealtCurrency": "{{dealtCurrency}}",
  "transactionId": "{{transactionId}}",
  "clOrderId": "{{clOrderId}}",
  "rfq": "{{rfq}}"
}
```

The pre-request script creates Date, Digest, type and Authorization.

Expected sequence:

`POST /v2/rfs/{{requestId}}`

## 4. Test Query Quote

Method: GET

URL:

`{{baseUrl}}/v2/rfs/{{requestId}}`

No SSO_TOKEN header is required.

The HMAC pre-request script generates:

- Date
- Digest
- type
- Authorization

Expected sequence:

`GET /v2/rfs/{{requestId}}`

## 5. Test MS complete flow

Start the Spring Boot application.

Then:

`POST {{msBaseUrl}}/api/deal-booking`

Use the complete OBPAY request body.

The MS performs:

`POST /v2/rfs/{requestId}`

then:

`GET /v2/rfs/{requestId}`

If Accept Quote fails, Query Quote is not called.

## 6. Important troubleshooting

If FX Integral says:

`Hmac Signature cannot be verified, a valid date or x-ray header is required`

check:

1. `hmacUserId` is populated.
2. `hmacSecret` is populated.
3. `hmacHeaders` is exactly `date request-line digest`.
4. `hmacStripPathPrefix` is `/v2`.
5. The URL is exactly `/v2/rfs/{{requestId}}`.
6. The generated Date header is present.
7. The Digest is the raw Base64 SHA-256 value, without `SHA-256=`.
8. There is no `SSO_TOKEN` dependency.

The uploaded collection uses the same HMAC conventions, including `/v2` removal before signing and `username` in the Authorization value.
