package com.mashreq.neofxrates.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
public class ApplicationConfig {
    private String baseUrl;
    private String acceptQuotePath = "/v2/rfsRequest";
    private String queryQuotePath = "/v2/rfs";
    private int queryDelayMs = 1000;
    private int queryAttempts = 5;
    private int connectTimeoutMs = 5000;
    private int readTimeoutMs = 15000;

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getAcceptQuotePath() { return acceptQuotePath; }
    public void setAcceptQuotePath(String acceptQuotePath) { this.acceptQuotePath = acceptQuotePath; }
    public String getQueryQuotePath() { return queryQuotePath; }
    public void setQueryQuotePath(String queryQuotePath) { this.queryQuotePath = queryQuotePath; }
    public int getQueryDelayMs() { return queryDelayMs; }
    public void setQueryDelayMs(int queryDelayMs) { this.queryDelayMs = queryDelayMs; }
    public int getQueryAttempts() { return queryAttempts; }
    public void setQueryAttempts(int queryAttempts) { this.queryAttempts = queryAttempts; }
    public int getConnectTimeoutMs() { return connectTimeoutMs; }
    public void setConnectTimeoutMs(int connectTimeoutMs) { this.connectTimeoutMs = connectTimeoutMs; }
    public int getReadTimeoutMs() { return readTimeoutMs; }
    public void setReadTimeoutMs(int readTimeoutMs) { this.readTimeoutMs = readTimeoutMs; }
}
